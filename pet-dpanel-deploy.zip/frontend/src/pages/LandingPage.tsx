import React, { useEffect, useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Layout, Button, Row, Col, Card, Statistic, List, Tag, Avatar, Spin, Space, Typography } from 'antd';
import {
  LoginOutlined, UserAddOutlined, TrophyOutlined, TeamOutlined,
  HeartOutlined, ThunderboltOutlined,
  RocketOutlined, BookOutlined, BulbOutlined,
  ArrowDownOutlined, RightOutlined, LogoutOutlined, UserSwitchOutlined,
} from '@ant-design/icons';
import { adminAPI, petAPI, leaderboardAPI, schoolAPI, classAPI, publicAPI } from '../utils/api';
import { useAuthStore } from '../store/authStore';
import { flagEnabled } from '../utils/featureFlags';
import { getSpeciesImage, elementColor, elementLabel } from '../utils/petImage';

const { Header, Content, Footer } = Layout;
const { Title, Paragraph, Text } = Typography;

const useMobile = () => {
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  useEffect(() => {
    const handler = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener('resize', handler);
    return () => window.removeEventListener('resize', handler);
  }, []);
  return isMobile;
};

const LandingPage: React.FC = () => {
  const navigate = useNavigate();
  const isMobile = useMobile();
  const statsRef = useRef<HTMLDivElement>(null);
  const { user, isAuthenticated, logout } = useAuthStore();

  const isStudent = user?.role === 'student';
  const isTeacher = user?.role === 'teacher' || user?.role === 'admin';

  const handleEnterClass = () => {
    if (isStudent && user?.class_slug) {
      navigate(`/c/${user.class_slug}/app`);
    } else if (isTeacher) {
      navigate('/workspace');
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const [loading, setLoading] = useState(true);
  const [siteSettings, setSiteSettings] = useState<any>({});
  const [stats, setStats] = useState<any>(null);
  const [species, setSpecies] = useState<any[]>([]);
  const [leaderboard, setLeaderboard] = useState<any[]>([]);
  const [schools, setSchools] = useState<any[]>([]);
    /* 年级概览：各年级的班级数/学生数/教师数（公开聚合，之前没有这个接口） */
  /* 年级概览：各年级的班级数/学生数/教师数（公开聚合，之前没有这个接口） */
    const [gradeStats, setGradeStats] = useState<any[]>([]);
    /** 全校公告（公开，只含 class_id 为空的） */
    const [announcements, setAnnouncements] = useState<any[]>([]);
    /** 登录用户的「我的班级」概览（学生/教师/admin 各不相同） */
  const [myClass, setMyClass] = useState<any>(null);
  const [myClassLoading, setMyClassLoading] = useState(false);
    /** 学校卡片展开后按需加载的班级明细，key 是 schoolId */
      const [schoolClassesMap, setSchoolClassesMap] = useState<Record<number, any[]>>({});
      /** 当前展开的学校卡片 */
      const [expandedSchool, setExpandedSchool] = useState<number | null>(null);
    const [noticeVisible, setNoticeVisible] = useState(true);

    useEffect(() => {
        loadData();
      }, []);

      // 登录用户额外拉「我的班级」概览。
      // 首页对访客展示全校概览，对已登录用户则要回答「我的班怎么样了」——
      // 两者关心的不是同一件事，所以分开取数而不是共用一份数据硬渲染。
      useEffect(() => {
        if (!isAuthenticated || !user) return;
        let cancelled = false;
        setMyClassLoading(true);
        const load = async () => {
          try {
            const classId = (user as any).class_id;
            if (classId) {
              // 本班学生/本班教师：home-summary 返回人数、教师、公告、班级动态
              const res = await classAPI.getHomeSummary(classId);
              if (!cancelled) setMyClass(res.data);
            } else if (isTeacher) {
              // 教师没有单一班级，取任教班级列表
              const res = await adminAPI.getClasses();
              if (!cancelled) setMyClass({ teacherClasses: res.data.classes || [] });
            }
          } catch (e) {
      // 没班/无权限时静默：首页不该因为这个接口失败而报错
          } finally {
            if (!cancelled) setMyClassLoading(false);
          }
        };
        load();
        return () => { cancelled = true; };
      }, [isAuthenticated, user?.class_id, isTeacher]);

    const loadData = async () => {
      // 排行榜改用公开榜：原来的 getLevelLeaderboard 需要登录，
      // 未登录时 401 → 数组为空 → 整个排行榜区块对访客不渲染（等于白做）。
      // 公开榜返回的是脱敏数据（无学生真名、无金币）。
      const results = await Promise.allSettled([
      adminAPI.getPublicSettings(),
        adminAPI.getPublicStatistics(),
        petAPI.getSpecies(),
        leaderboardAPI.getPublicLeaderboard({ limit: 10 }),
        schoolAPI.getSchools(),
              publicAPI.getByGrade(),
        publicAPI.getAnnouncements({ limit: 5 }),
      ]);

      const [settingsRes, statsRes, speciesRes, lbRes, schoolsRes, gradeRes, annRes] = results;

      if (settingsRes.status === 'fulfilled') {
      const s = settingsRes.value.data.settings || {};
        setSiteSettings(s);
        document.title = s.site_name || '班级宠物养成系统';
      }
    if (statsRes.status === 'fulfilled') setStats(statsRes.value.data.statistics);
      if (speciesRes.status === 'fulfilled') setSpecies(speciesRes.value.data.species || []);
    if (lbRes.status === 'fulfilled') setLeaderboard(lbRes.value.data.leaderboard || []);
      if (schoolsRes.status === 'fulfilled') setSchools(schoolsRes.value.data.schools || []);
      /* 公开班级列表不再在首屏拉取：学校卡片现在用后端聚合字段，
      班级明细改成点「查看班级」才按需加载，首屏少发一个请求。*/
      if (gradeRes.status === 'fulfilled') setGradeStats(gradeRes.value.data.grades || []);
      if (annRes.status === 'fulfilled') setAnnouncements(annRes.value.data.announcements || []);

      setLoading(false);
    };

    /** 展开学校卡片时才去拉该校的班级明细，避免首屏一次请求十几个学校 */
    const toggleSchool = async (schoolId: number) => {
      if (expandedSchool === schoolId) {
        setExpandedSchool(null);
        return;
      }
      setExpandedSchool(schoolId);
      if (schoolClassesMap[schoolId]) return;
      try {
     const res = await schoolAPI.getClassesOfSchool(schoolId);
        setSchoolClassesMap((prev) => ({ ...prev, [schoolId]: res.data.classes || [] }));
      } catch (e) {
        setSchoolClassesMap((prev) => ({ ...prev, [schoolId]: [] }));
      }
    };

  const scrollToStats = () => {
    statsRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  if (loading) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', background: '#f0f2f5' }}>
        <Spin size="large"><span style={{ paddingLeft: 16, color: '#666' }}>加载中...</span></Spin>
      </div>
    );
  }

  const features = [
    { icon: <UserAddOutlined />, color: '#667eea', title: '注册加入', desc: '注册账号并加入你的班级，开启专属学习旅程' },
    { icon: <HeartOutlined />, color: '#eb2f96', title: '领养宠物', desc: '选择心仪的宠物伙伴，见证它一步步成长' },
    { icon: <BookOutlined />, color: '#52c41a', title: '完成作业', desc: '完成老师布置的作业，获得经验值和金币奖励' },
    { icon: <ThunderboltOutlined />, color: '#fa541c', title: '对战PK', desc: '和同学的宠物一决高下，用知识的力量战斗' },
  ];

  return (
    <Layout style={{ minHeight: '100vh', background: '#f0f2f5' }}>
      {/* Header */}
      <Header style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
        boxShadow: '0 2px 8px rgba(0,0,0,0.15)', zIndex: 100,
        padding: isMobile ? '0 12px' : '0 24px',
        height: isMobile ? 56 : 64, position: 'sticky', top: 0,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: isMobile ? 10 : 20, cursor: 'pointer' }} onClick={() => navigate('/')}>
          <span style={{ fontSize: isMobile ? 22 : 28 }}>{siteSettings.site_logo || '🐾'}</span>
          <span style={{ fontSize: isMobile ? 14 : 18, fontWeight: 'bold', color: '#fff' }}>
            {siteSettings.site_name || '班级宠物养成系统'}
          </span>
        </div>
        <Space size={isMobile ? 8 : 12}>
          {isAuthenticated ? (
            <>
              {(isStudent && user?.class_slug) || isTeacher ? (
                <Button type="primary" ghost icon={<RocketOutlined />} size={isMobile ? 'small' : 'middle'} onClick={handleEnterClass}>进入班级</Button>
              ) : null}
              {!isMobile && <span style={{ color: 'rgba(255,255,255,0.85)', fontSize: 14 }}>欢迎，{user?.real_name || user?.username}</span>}
              <Button icon={<LogoutOutlined />} size={isMobile ? 'small' : 'middle'} style={{ background: 'rgba(255,255,255,0.15)', borderColor: 'rgba(255,255,255,0.3)', color: '#fff' }} onClick={handleLogout}>退出登录</Button>
            </>
          ) : (
            <>
              <Button type="primary" ghost icon={<LoginOutlined />} size={isMobile ? 'small' : 'middle'} onClick={() => navigate('/login')}>登录</Button>
              {flagEnabled(siteSettings, 'registration_enabled') && (
                <Button icon={<UserAddOutlined />} size={isMobile ? 'small' : 'middle'} style={{ background: '#fff', borderColor: '#fff' }} onClick={() => navigate('/register')}>注册</Button>
              )}
            </>
          )}
        </Space>
      </Header>

      <Content>
        {/* Hero Section */}
        <div style={{
          background: 'linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%)',
          padding: isMobile ? '60px 20px 50px' : '100px 40px 80px',
          textAlign: 'center', position: 'relative', overflow: 'hidden',
        }}>
          <div style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, opacity: 0.1, backgroundImage: 'radial-gradient(circle at 20% 50%, #fff 1px, transparent 1px), radial-gradient(circle at 80% 20%, #fff 1px, transparent 1px)', backgroundSize: '60px 60px' }} />
          <div style={{ position: 'relative', maxWidth: 800, margin: '0 auto' }}>
            <Title style={{ color: '#fff', fontSize: isMobile ? 28 : 44, marginBottom: 16, fontWeight: 700 }}>
              {siteSettings.site_description || '让学习充满乐趣，和同学一起养育专属宠物'}
            </Title>
            <Paragraph style={{ color: 'rgba(255,255,255,0.85)', fontSize: isMobile ? 15 : 18, marginBottom: 36, maxWidth: 600, margin: '0 auto 36px' }}>
              通过完成作业获得经验值，让你的宠物不断成长进化，和全班同学一起在知识的海洋中冒险！
            </Paragraph>
            <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
              {isAuthenticated ? (
                <>
                  {(isStudent && user?.class_slug) || isTeacher ? (
                    <Button type="primary" size="large" icon={<RocketOutlined />} style={{ height: isMobile ? 42 : 48, padding: isMobile ? '0 20px' : '0 32px', fontSize: isMobile ? 14 : 16, borderRadius: 8, boxShadow: '0 4px 15px rgba(0,0,0,0.2)', flex: isMobile ? '1 1 40%' : undefined, minWidth: isMobile ? 120 : undefined }} onClick={handleEnterClass}>
                      进入班级
                    </Button>
                  ) : null}
                  <Button size="large" ghost icon={<ArrowDownOutlined />} style={{ height: isMobile ? 42 : 48, padding: isMobile ? '0 20px' : '0 32px', fontSize: isMobile ? 14 : 16, borderRadius: 8, color: '#fff', borderColor: 'rgba(255,255,255,0.6)', flex: isMobile ? '1 1 40%' : undefined, minWidth: isMobile ? 120 : undefined }} onClick={scrollToStats}>
                    了解更多
                  </Button>
                </>
              ) : (
                <>
                  {flagEnabled(siteSettings, 'registration_enabled') && (
                  <Button type="primary" size="large" icon={<RocketOutlined />} style={{ height: isMobile ? 42 : 48, padding: isMobile ? '0 20px' : '0 32px', fontSize: isMobile ? 14 : 16, borderRadius: 8, boxShadow: '0 4px 15px rgba(0,0,0,0.2)', flex: isMobile ? '1 1 40%' : undefined, minWidth: isMobile ? 120 : undefined }} onClick={() => navigate('/register')}>
                    立即注册
                  </Button>
                )}
                  <Button size="large" ghost icon={<ArrowDownOutlined />} style={{ height: isMobile ? 42 : 48, padding: isMobile ? '0 20px' : '0 32px', fontSize: isMobile ? 14 : 16, borderRadius: 8, color: '#fff', borderColor: 'rgba(255,255,255,0.6)', flex: isMobile ? '1 1 40%' : undefined, minWidth: isMobile ? 120 : undefined }} onClick={scrollToStats}>
                    了解更多
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>

        {/* 我的班级：登录用户置顶展示，回答「我的班怎么样了」而不是「全校怎么样」 */}
        {isAuthenticated && !myClassLoading && (myClass?.class || (myClass?.teacherClasses?.length ?? 0) > 0) && (
          <div style={{ maxWidth: 1200, margin: '0 auto', padding: isMobile ? '24px 12px 0' : '32px 24px 0' }}>
 <Card
              style={{ borderRadius: 12, boxShadow: '0 4px 20px rgba(0,0,0,0.08)', borderLeft: `4px solid ${myClass?.class?.school_theme || '#667eea'}` }}
          >
     <div style={{ display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
      <div style={{ flex: 1, minWidth: 200 }}>
     <Text strong style={{ fontSize: isMobile ? 16 : 18 }}>
       {myClass?.class ? myClass.class.name : '我任教的班级'}
      </Text>
        <div style={{ color: '#8c8c8c', fontSize: 12, marginTop: 4 }}>
  {myClass?.class
      ? [myClass.class.school_name, myClass.class.grade].filter(Boolean).join(' · ')
     : `${myClass?.teacherClasses?.length || 0} 个任教班级`}
          </div>
        </div>
        {myClass?.class && (
     <Space size={isMobile ? 12 : 24} wrap>
   <Statistic title="班级人数" value={myClass.student_count || 0} valueStyle={{ fontSize: isMobile ? 18 : 22, color: '#52c41a' }} />
            <Statistic title="任课教师" value={myClass.teachers?.length || 0} valueStyle={{ fontSize: isMobile ? 18 : 22, color: '#667eea' }} />
            </Space>
          )}
  <Button type="primary" onClick={handleEnterClass} icon={<RocketOutlined />}>
        进入我的班级
       </Button>
          </div>
    </Card>
          </div>
        )}

        {/* Stats Section */}
                {stats && (
            <div ref={statsRef} style={{ maxWidth: 1200, margin: isMobile ? '-30px auto 0' : '-40px auto 0', padding: isMobile ? '0 12px' : '0 24px', position: 'relative', zIndex: 10 }}>
                    <Row gutter={[16, 16]}>
            {[
                    /* 学校与班级/学生/教师是访客最关心的「这学校什么规模」；
             宠物总数、战斗次数对访客判断学校没有意义，去掉换成教师与学校数。
             每张卡片都可点进对应的名录页：数字是结论，点进去才看得到细节。 */
            { icon: <TeamOutlined />, color: '#667eea', value: stats.schools, title: '学校数量', path: '/schools' },
         { icon: <TeamOutlined />, color: '#52c41a', value: stats.classes, title: '班级数量', path: '/classes' },
                  { icon: <UserAddOutlined />, color: '#fa8c16', value: stats.teachers, title: '在职教师', path: '/teachers' },
                 { icon: <UserAddOutlined />, color: '#eb2f96', value: stats.students, title: '在校学生', path: '/students' },
            ].map((item, idx) => (
                   <Col xs={12} sm={6} key={idx}>
           <Card
             hoverable
             onClick={() => navigate(item.path)}
             style={{ borderRadius: 12, boxShadow: '0 4px 20px rgba(0,0,0,0.08)', textAlign: 'center', borderTop: `3px solid ${item.color}`, cursor: 'pointer' }}
             styles={{ body: { padding: isMobile ? '16px 8px' : '24px 16px' } }}
           >
                    <div style={{ fontSize: isMobile ? 24 : 32, color: item.color, marginBottom: 8 }}>{item.icon}</div>
           <Statistic value={item.value} valueStyle={{ color: item.color, fontSize: isMobile ? 22 : 28, fontWeight: 'bold' }} />
                    <div style={{ color: '#8c8c8c', fontSize: 13, marginTop: 4 }}>
                      {item.title}
                      <RightOutlined style={{ fontSize: 10, marginLeft: 4, color: '#ccc' }} />
                    </div>
            </Card>
               </Col>
           ))}
          </Row>
                  </div>
              )}

                {/* Grade Overview：按年级聚合，公开接口。之前全仓库没有 GROUP BY grade 的查询 */}
              {gradeStats.length > 0 && (
                  <div style={{ maxWidth: 1200, margin: '0 auto', padding: isMobile ? '40px 16px' : '60px 24px' }}>
              <div style={{ textAlign: 'center', marginBottom: isMobile ? 24 : 40 }}>
                      <Title level={2} style={{ marginBottom: 8, fontSize: isMobile ? 20 : undefined }}>各年级概览</Title>
           <Paragraph style={{ color: '#8c8c8c', fontSize: isMobile ? 14 : 16 }}>看看各年级的班级与学生规模</Paragraph>
                    </div>
               <Row gutter={[16, 16]}>
           {gradeStats.map((g: any) => (
                    <Col xs={12} sm={8} md={6} key={g.grade}>
         <Card style={{ borderRadius: 12, textAlign: 'center', boxShadow: '0 2px 12px rgba(0,0,0,0.06)' }}
            styles={{ body: { padding: isMobile ? '14px 8px' : '20px 16px' } }}>
         <div style={{ fontSize: isMobile ? 17 : 20, fontWeight: 'bold', marginBottom: 10, color: '#333' }}>{g.grade}</div>
            <Space size={isMobile ? 4 : 12} wrap style={{ justifyContent: 'center' }}>
           <Text type="secondary" style={{ fontSize: isMobile ? 11 : 13 }}>{g.class_count} 个班</Text>
           <Text type="secondary" style={{ fontSize: isMobile ? 11 : 13 }}>{g.student_count} 名学生</Text>
           <Text type="secondary" style={{ fontSize: isMobile ? 11 : 13 }}>{g.teacher_count} 位老师</Text>
                    </Space>
                 </Card>
              </Col>
                  ))}
                  </Row>
              </div>
                )}

                {/* Announcements：全校公告（公开）。班级内部公告不在这里出现 */}
                {announcements.length > 0 && (
             <div style={{ maxWidth: 1200, margin: '0 auto', padding: isMobile ? '0 16px 40px' : '0 24px 60px' }}>
             <Title level={3} style={{ marginBottom: isMobile ? 16 : 24 }}>📢 校园公告</Title>
            <Card style={{ borderRadius: 12, boxShadow: '0 2px 12px rgba(0,0,0,0.06)' }}>
                {announcements.map((a: any, i: number) => (
              <div key={a.id} style={{ padding: isMobile ? '10px 0' : '14px 0', borderTop: i === 0 ? 'none' : '1px solid #f0f0f0' }}>
             <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4, flexWrap: 'wrap' }}>
               {a.priority > 0 && <Tag color="red">置顶</Tag>}
          <Text strong style={{ fontSize: isMobile ? 14 : 16 }}>{a.title}</Text>
                <span style={{ color: '#bbb', fontSize: 12, marginLeft: 'auto' }}>
                 {a.created_at ? new Date(a.created_at).toLocaleDateString('zh-CN') : ''}
               </span>
                 </div>
          {a.content && <Paragraph style={{ margin: 0, color: '#666', fontSize: isMobile ? 12 : 14 }} ellipsis={{ rows: 2 }}>{a.content}</Paragraph>}
              </div>
                  ))}
              </Card>
             </div>
                )}

        {/* How It Works */}
        <div style={{ maxWidth: 1200, margin: '0 auto', padding: isMobile ? '40px 16px' : '60px 24px' }}>
          <div style={{ textAlign: 'center', marginBottom: isMobile ? 24 : 40 }}>
            <Title level={2} style={{ marginBottom: 8, fontSize: isMobile ? 20 : undefined }}>如何开始？</Title>
            <Paragraph style={{ color: '#8c8c8c', fontSize: isMobile ? 14 : 16 }}>简单四步，开启你的宠物养成之旅</Paragraph>
          </div>
          <Row gutter={[24, 24]}>
            {features.map((f, idx) => (
              <Col xs={12} md={6} key={idx}>
                <Card hoverable style={{ borderRadius: 12, textAlign: 'center', height: '100%', boxShadow: '0 2px 12px rgba(0,0,0,0.06)' }} styles={{ body: { padding: isMobile ? '16px 10px' : '32px 20px' } }}>
                  <div style={{ width: isMobile ? 44 : 56, height: isMobile ? 44 : 56, borderRadius: '50%', background: `${f.color}15`, display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 12px', fontSize: isMobile ? 20 : 24, color: f.color }}>
                    {f.icon}
                  </div>
                  <div style={{ fontSize: 11, color: '#bbb', marginBottom: 6 }}>第 {idx + 1} 步</div>
                  <Title level={5} style={{ marginBottom: 6, fontSize: isMobile ? 14 : 16 }}>{f.title}</Title>
                  <Paragraph style={{ color: '#666', fontSize: isMobile ? 12 : 13, margin: 0 }}>{f.desc}</Paragraph>
                </Card>
              </Col>
            ))}
          </Row>
        </div>

        {/* Pet Species Catalog */}
        {species.length > 0 && (
          <div style={{ background: '#fff', padding: isMobile ? '40px 16px' : '60px 24px' }}>
            <div style={{ maxWidth: 1200, margin: '0 auto' }}>
              <div style={{ textAlign: 'center', marginBottom: isMobile ? 24 : 40 }}>
                <Title level={2} style={{ marginBottom: 8, fontSize: isMobile ? 20 : undefined }}><BulbOutlined style={{ color: '#667eea' }} /> 宠物种类图鉴</Title>
                <Paragraph style={{ color: '#8c8c8c', fontSize: isMobile ? 14 : 16 }}>选择你最喜欢的宠物伙伴，开启冒险旅程</Paragraph>
              </div>
              <Row gutter={[20, 20]}>
                {species.map((sp: any) => (
                  <Col xs={12} sm={8} md={6} key={sp.id}>
                    <Card hoverable style={{ borderRadius: 12, overflow: 'hidden', height: '100%' }}
                      cover={
                        <div style={{ height: isMobile ? 100 : 160, display: 'flex', justifyContent: 'center', alignItems: 'center', background: 'linear-gradient(135deg, #f5f7fa 0%, #e8ecf1 100%)', padding: isMobile ? 10 : 16 }}>
                          <img alt={sp.name} src={getSpeciesImage(sp.image_urls, sp.name)} style={{ maxHeight: '100%', maxWidth: '100%', objectFit: 'contain' }} onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                        </div>
                      }
                      styles={{ body: { padding: isMobile ? '8px 10px' : '12px 16px' } }}
                    >
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4, gap: 4 }}>
                        <Text strong style={{ fontSize: isMobile ? 13 : 15, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{sp.name}</Text>
                        {/* 标签文案走 elementLabel：库里存的是英文键（fire/grass…），
                            直接显出来像是没做完的界面；颜色走 elementColor，与其他页面同一套 */}
                        {sp.element_type && <Tag color={elementColor(sp.element_type)} style={{ margin: 0, fontSize: isMobile ? 11 : 12, padding: '0 4px', lineHeight: isMobile ? '18px' : '20px' }}>{elementLabel(sp.element_type)}</Tag>}
                      </div>
                      {sp.description && !isMobile && <Paragraph ellipsis={{ rows: 2 }} style={{ color: '#8c8c8c', fontSize: 12, margin: 0 }}>{sp.description}</Paragraph>}
                    </Card>
                  </Col>
                ))}
              </Row>
            </div>
          </div>
        )}

        {/* Leaderboard */}
        {leaderboard.length > 0 && (
          <div style={{ maxWidth: 1200, margin: '0 auto', padding: isMobile ? '40px 16px' : '60px 24px' }}>
            <div style={{ textAlign: 'center', marginBottom: isMobile ? 24 : 40 }}>
              <Title level={2} style={{ marginBottom: 8, fontSize: isMobile ? 20 : undefined }}><TrophyOutlined style={{ color: '#faad14' }} /> 全服排行榜</Title>
              <Paragraph style={{ color: '#8c8c8c', fontSize: isMobile ? 14 : 16 }}>看看谁的宠物最强，努力学习冲上榜首！</Paragraph>
            </div>
            <Card style={{ borderRadius: 12, boxShadow: '0 2px 12px rgba(0,0,0,0.06)', overflow: 'hidden' }}>
              <List
                dataSource={leaderboard}
                renderItem={(item: any, index: number) => (
                  <List.Item style={{ padding: isMobile ? '10px 12px' : undefined }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: isMobile ? 8 : 12, width: '100%' }}>
                      <Avatar style={{ background: index === 0 ? '#faad14' : index === 1 ? '#d9d9d9' : index === 2 ? '#d48806' : '#e8e8e8', color: index < 3 ? '#fff' : '#666', fontWeight: 'bold', fontSize: isMobile ? 13 : 16, flexShrink: 0, width: isMobile ? 32 : 40, height: isMobile ? 32 : 40 }}>
                        {index + 1}
                      </Avatar>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ fontWeight: 'bold', fontSize: isMobile ? 13 : 15 }}>{item.name || item.pet_name || '宠物'}</div>
                        <div style={{ color: '#8c8c8c', fontSize: isMobile ? 11 : 13, marginTop: 2 }}>
                          {/* 公开榜刻意不返回学生真名，展示的是宠物昵称 + 所属学校/班级。
       登录用户看到的榜单（含真名）走的是另一个需要登录的接口。*/}
      {item.species_name || '-'}
              {item.school_name ? ` · ${item.school_name}` : ''}
        {item.class_name ? ` ${item.class_name}` : ''}
                        </div>
                      </div>
                      <div style={{ textAlign: 'right', flexShrink: 0 }}>
                        <div style={{ color: '#667eea', fontWeight: 'bold', fontSize: isMobile ? 14 : 16 }}>Lv.{item.level}</div>
                        {!isMobile && <div style={{ color: '#999', fontSize: 12 }}>{item.exp} EXP</div>}
                      </div>
                    </div>
                  </List.Item>
                )}
              />
            </Card>
          </div>
        )}

        {/* Schools */}
        {schools.length > 0 && (
          <div style={{ background: '#fff', padding: isMobile ? '40px 16px' : '60px 24px' }}>
            <div style={{ maxWidth: 1200, margin: '0 auto' }}>
              <div style={{ textAlign: 'center', marginBottom: isMobile ? 24 : 40 }}>
                <Title level={2} style={{ marginBottom: 8, fontSize: isMobile ? 20 : undefined }}><TeamOutlined style={{ color: '#52c41a' }} /> 加入学校</Title>
                <Paragraph style={{ color: '#8c8c8c', fontSize: isMobile ? 14 : 16 }}>找到你的学校，和同校同学一起养成宠物</Paragraph>
              </div>
              <Row gutter={[20, 20]}>
                {schools.map((school: any) => {
                                  return (
                    <Col xs={24} sm={12} md={8} key={school.id}>
                      <Card hoverable style={{ borderRadius: 12, borderLeft: `4px solid ${school.theme_color || '#667eea'}`, height: '100%' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12 }}>
                          {school.logo ? <Avatar src={school.logo} size={40} /> : <Avatar style={{ background: school.theme_color || '#667eea' }} size={40} icon={<TeamOutlined />} />}
                          <div>
                            <Text strong style={{ fontSize: 16 }}>{school.name}</Text>
                            <div style={{ color: '#8c8c8c', fontSize: 12 }}>{school.city || ''}{school.city && school.region ? ' · ' : ''}{school.region || ''}</div>
                          </div>
                        </div>
                        <Space size={isMobile ? 8 : 16} wrap>
                                  <Text type="secondary"><TeamOutlined /> {school.class_count || 0} 个班级</Text>
                              {/* 学生数改用后端聚合值 school.student_count。
                          原先这里是前端把 publicClasses 里的 student_count 相加，
                                  而那张列表只含 is_public=1 的班 —— 私密班的学生被漏掉了。*/}
                                  <Text type="secondary"><UserAddOutlined /> {school.student_count || 0} 名学生</Text>
                                  {school.teacher_count > 0 && (
                              <Text type="secondary"><UserSwitchOutlined /> {school.teacher_count} 位教师</Text>
                                  )}
                           </Space>
                              {school.grades && school.grades.length > 0 && (
                            <div style={{ marginTop: 8 }}>
                            {school.grades.map((g: string) => <Tag key={g} color="blue">{g}</Tag>)}
                         </div>
                                      )}
                               {/* 班级明细：点「查看班级」才加载，避免首屏把每个学校都拉一遍 */}
                             <div style={{ marginTop: 12, borderTop: '1px solid #f0f0f0', paddingTop: 10 }}>
                            <Button
                           type="link"
                              size="small"
                              style={{ padding: 0, color: school.theme_color || '#667eea' }}
                           onClick={() => toggleSchool(school.id)}
                               >
                             {expandedSchool === school.id ? '收起班级' : `查看班级 (${school.class_count || 0})`}
                             <ArrowDownOutlined style={{ fontSize: 10, transform: expandedSchool === school.id ? 'rotate(180deg)' : undefined, transition: 'transform .2s' }} />
                                  </Button>
                                    {expandedSchool === school.id && (
                                        <div style={{ marginTop: 8 }}>
                         {schoolClassesMap[school.id] === undefined ? (
                                    <Spin size="small"><span style={{ paddingLeft: 8, color: '#999', fontSize: 12 }}>加载中…</span></Spin>
                                ) : schoolClassesMap[school.id].length === 0 ? (
                             <div style={{ color: '#999', fontSize: 12, padding: '6px 0' }}>该校暂未创建班级</div>
                             ) : (
                                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                                {schoolClassesMap[school.id].map((c: any) => (
                                 <div
                                key={c.id}
                               style={{
                           display: 'flex', alignItems: 'center', gap: 8, padding: '6px 8px',
                                  background: '#fafafa', borderRadius: 6, cursor: c.slug ? 'pointer' : 'default',
                             }}
                             onClick={() => c.slug && navigate(`/c/${c.slug}`)}
                                  >
                                <span style={{ fontSize: 13, color: '#333', fontWeight: 500 }}>{c.name}</span>
                                      {c.grade && <Tag color="blue" style={{ margin: 0, fontSize: 11 }}>{c.grade}</Tag>}
                                    {c.head_teacher_name && (
                           <span style={{ fontSize: 11, color: '#999' }}>班主任 {c.head_teacher_name}</span>
                                 )}
                            <span style={{ marginLeft: 'auto', fontSize: 11, color: '#bbb' }}>
                               {c.student_count || 0} 人
                                    </span>
                            {c.is_public
                            ? <RightOutlined style={{ fontSize: 10, color: '#ccc' }} />
                           : <Tag style={{ margin: 0, fontSize: 10, color: '#999' }}>未公开</Tag>}
                           </div>
                               ))}
                            </div>
                           )}
                            </div>
                          )}
                        </div>
                      </Card>
                                                        </Col>
                                                    );
                                                 })}
              </Row>
            </div>
          </div>
        )}

        {/* CTA Section */}
        <div style={{
          background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
          padding: isMobile ? '40px 20px' : '60px 40px',
          textAlign: 'center',
        }}>
          <Title level={2} style={{ color: '#fff', marginBottom: 12, fontSize: isMobile ? 20 : undefined }}>
            {isAuthenticated ? '开始你的学习之旅' : '准备好开始了吗？'}
          </Title>
          <Paragraph style={{ color: 'rgba(255,255,255,0.85)', fontSize: isMobile ? 14 : 16, marginBottom: 32 }}>
            {isAuthenticated ? '进入班级，和同学们一起养成宠物吧' : '加入班级宠物养成系统，让学习变得更有趣'}
          </Paragraph>
          <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
            {isAuthenticated ? (
              <>
                {(isStudent && user?.class_slug) || isTeacher ? (
                  <Button type="primary" size="large" icon={<RocketOutlined />} style={{ height: isMobile ? 42 : 48, padding: isMobile ? '0 20px' : '0 32px', fontSize: isMobile ? 14 : 16, borderRadius: 8, background: '#fff', color: '#667eea', borderColor: '#fff', fontWeight: 600, flex: isMobile ? '1 1 40%' : undefined, minWidth: isMobile ? 120 : undefined }} onClick={handleEnterClass}>
                    进入班级
                  </Button>
                ) : null}
                <Button size="large" ghost icon={<LogoutOutlined />} style={{ height: isMobile ? 42 : 48, padding: isMobile ? '0 20px' : '0 32px', fontSize: isMobile ? 14 : 16, borderRadius: 8, color: '#fff', borderColor: 'rgba(255,255,255,0.6)', flex: isMobile ? '1 1 40%' : undefined, minWidth: isMobile ? 120 : undefined }} onClick={handleLogout}>
                  退出登录
                </Button>
              </>
            ) : (
              <>
                {flagEnabled(siteSettings, 'registration_enabled') && (
                <Button type="primary" size="large" icon={<RocketOutlined />} style={{ height: isMobile ? 42 : 48, padding: isMobile ? '0 20px' : '0 32px', fontSize: isMobile ? 14 : 16, borderRadius: 8, background: '#fff', color: '#667eea', borderColor: '#fff', fontWeight: 600, flex: isMobile ? '1 1 40%' : undefined, minWidth: isMobile ? 120 : undefined }} onClick={() => navigate('/register')}>
                  立即注册
                </Button>
              )}
                <Button size="large" ghost icon={<LoginOutlined />} style={{ height: isMobile ? 42 : 48, padding: isMobile ? '0 20px' : '0 32px', fontSize: isMobile ? 14 : 16, borderRadius: 8, color: '#fff', borderColor: 'rgba(255,255,255,0.6)', flex: isMobile ? '1 1 40%' : undefined, minWidth: isMobile ? 120 : undefined }} onClick={() => navigate('/login')}>
                  已有账号？登录
                </Button>
              </>
            )}
          </div>
        </div>
      </Content>

      {/* Footer */}
      <Footer style={{
        background: 'linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)',
        color: 'rgba(255,255,255,0.65)', textAlign: 'center',
        padding: isMobile ? '24px 12px' : '32px 50px',
      }}>
        <div style={{ maxWidth: 1200, margin: '0 auto' }}>
          <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 8, marginBottom: 12 }}>
            <span style={{ fontSize: 20 }}>{siteSettings.site_logo || '🐾'}</span>
            <span style={{ color: '#fff', fontWeight: 'bold', fontSize: 16 }}>{siteSettings.site_name || '班级宠物养成系统'}</span>
          </div>
          <p style={{ color: 'rgba(255,255,255,0.45)', fontSize: 13, marginBottom: 12 }}>
            {siteSettings.site_description || '寓教于乐，让学习更有趣'}
          </p>
          <div style={{ display: 'flex', justifyContent: 'center', gap: 24, marginBottom: 12 }}>
            <a style={{ color: 'rgba(255,255,255,0.65)', fontSize: 13, cursor: 'pointer' }} onClick={() => navigate('/about')}>关于我们</a>
            <a style={{ color: 'rgba(255,255,255,0.65)', fontSize: 13, cursor: 'pointer' }} onClick={() => navigate('/help')}>使用帮助</a>
            <a style={{ color: 'rgba(255,255,255,0.65)', fontSize: 13, cursor: 'pointer' }} onClick={() => navigate('/privacy')}>隐私政策</a>
            <a style={{ color: 'rgba(255,255,255,0.65)', fontSize: 13, cursor: 'pointer' }} onClick={() => navigate('/contact')}>联系我们</a>
          </div>
          <div style={{ borderTop: '1px solid rgba(255,255,255,0.1)', paddingTop: 12 }}>
            <span style={{ fontSize: 12 }}>{siteSettings.site_footer || '© 2026 班级宠物养成系统'}</span>
            <span style={{ margin: '0 8px', fontSize: 12 }}>|</span>
            <span style={{ fontSize: 12 }}>用 <HeartOutlined style={{ color: '#ff4d4f' }} /> 打造</span>
          </div>
        </div>
      </Footer>

      {siteSettings.home_notice && noticeVisible && (
        <div style={{
          position: 'fixed',
          bottom: isMobile ? 80 : 24,
          right: isMobile ? 12 : 24,
          left: isMobile ? 12 : 'auto',
          maxWidth: isMobile ? 'none' : 340,
          padding: '14px 18px',
          background: '#fff',
          borderRadius: 12,
          boxShadow: '0 6px 20px rgba(0,0,0,0.18)',
          zIndex: 1000,
          borderLeft: '4px solid #1890ff',
          fontSize: isMobile ? 13 : 14,
          lineHeight: 1.8,
          whiteSpace: 'pre-wrap',
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
            <span style={{ fontWeight: 600, color: '#1890ff', fontSize: isMobile ? 14 : 15 }}>📢 公告</span>
            <span style={{ cursor: 'pointer', color: '#999', fontSize: 18, lineHeight: 1, padding: '0 4px' }} onClick={() => setNoticeVisible(false)}>×</span>
          </div>
          <div style={{ color: '#333' }}>{siteSettings.home_notice}</div>
        </div>
      )}
    </Layout>
  );
};

export default LandingPage;
