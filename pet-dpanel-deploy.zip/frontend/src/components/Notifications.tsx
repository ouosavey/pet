import React, { useEffect, useState } from 'react';
import { Card, List, Badge, Button, Tag, Empty, Spin, Popconfirm, Tabs, message, Space } from 'antd';
import {
  BellOutlined,
  CheckOutlined,
  DeleteOutlined,
  MessageOutlined,
  HeartOutlined,
  GiftOutlined,
  TrophyOutlined,
  UserAddOutlined,
  NotificationOutlined,
  EditOutlined,
  TeamOutlined,
} from '@ant-design/icons';
import { notificationAPI } from '../utils/api';
import { visibleNotificationTypes } from '../utils/notificationTypes';
import { useAuthStore } from '../store/authStore';

// 各角色可见的通知类型统一放在 utils/notificationTypes，避免和左侧红点的白名单各写一份而漂移
const adminVisibleTypes = visibleNotificationTypes('admin');
const teacherVisibleTypes = visibleNotificationTypes('teacher');
const studentVisibleTypes = visibleNotificationTypes('student');

const useMobile = () => {
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  useEffect(() => {
    const handler = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener('resize', handler);
    return () => window.removeEventListener('resize', handler);
  }, []);
  return isMobile;
};

const typeConfig: Record<string, { icon: React.ReactNode; color: string; label: string }> = {
  friend_request: { icon: <UserAddOutlined />, color: 'blue', label: '好友请求' },
  friend_accepted: { icon: <UserAddOutlined />, color: 'green', label: '好友通过' },
  class_join_request: { icon: <TeamOutlined />, color: '#722ed1', label: '班级加入' },
  gift_received: { icon: <GiftOutlined />, color: 'magenta', label: '收到礼物' },
  achievement: { icon: <TrophyOutlined />, color: 'gold', label: '成就解锁' },
  post_like: { icon: <HeartOutlined />, color: 'red', label: '动态被赞' },
  post_comment: { icon: <MessageOutlined />, color: 'cyan', label: '动态评论' },
  forum_reply: { icon: <MessageOutlined />, color: 'purple', label: '论坛回复' },
  forum_like: { icon: <HeartOutlined />, color: 'red', label: '论坛点赞' },
  forum_quote: { icon: <MessageOutlined />, color: 'orange', label: '被引用' },
  answer_changed: { icon: <EditOutlined />, color: 'volcano', label: '答案更正' },
  system: { icon: <NotificationOutlined />, color: 'default', label: '系统通知' },
};

interface NotificationItem {
  id: number;
  user_id: number;
  type: string;
  title: string;
  content?: string;
  source_type?: string;
  source_id?: number;
  is_read: number;
  read_at?: string;
  created_at: string;
}

const Notifications: React.FC = () => {
  const { isAuthenticated, user } = useAuthStore();
  const isAdmin = user?.role === 'admin';
  const isTeacher = user?.role === 'teacher';
  const isMobile = useMobile();
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [unreadByType, setUnreadByType] = useState<Record<string, number>>({});
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<string>('all');

  useEffect(() => {
    if (isAuthenticated) {
      loadUnreadCount();
      loadNotifications();
    }
  }, [isAuthenticated, activeTab]);

  const loadUnreadCount = async () => {
    try {
      const res = await notificationAPI.getUnreadCount();
      const byType = res.data.by_type || {};
      setUnreadByType(byType);
      if (isAdmin) {
        setUnreadCount(adminVisibleTypes.reduce((sum, t) => sum + (byType[t] || 0), 0));
      } else if (isTeacher) {
        setUnreadCount(teacherVisibleTypes.reduce((sum, t) => sum + (byType[t] || 0), 0));
      } else {
        setUnreadCount(studentVisibleTypes.reduce((sum, t) => sum + (byType[t] || 0), 0));
      }
    } catch (e) {
      console.error('获取未读数失败:', e);
    }
  };

  const loadNotifications = async () => {
    setLoading(true);
    try {
      const params: any = {};
      if (activeTab !== 'all') {
        params.type = activeTab;
      } else if (isAdmin) {
        params.types = adminVisibleTypes.join(',');
      } else if (isTeacher) {
        params.types = teacherVisibleTypes.join(',');
      } else {
        params.types = studentVisibleTypes.join(',');
      }

      const res = await notificationAPI.getNotifications(params);
      let items = res.data.notifications || [];
      if (isAdmin && activeTab === 'all') {
        items = items.filter((n: NotificationItem) => adminVisibleTypes.includes(n.type));
      } else if (isTeacher && activeTab === 'all') {
        items = items.filter((n: NotificationItem) => teacherVisibleTypes.includes(n.type));
      } else if (activeTab === 'all') {
        items = items.filter((n: NotificationItem) => studentVisibleTypes.includes(n.type));
      }
      setNotifications(items);
    } catch (e) {
      console.error('加载通知失败:', e);
    } finally {
      setLoading(false);
    }
  };

  const handleMarkAsRead = async (id: number) => {
    try {
      await notificationAPI.markAsRead(id);
      setNotifications(prev =>
        prev.map(n => n.id === id ? { ...n, is_read: 1, read_at: new Date().toISOString() } : n)
      );
      setUnreadCount(Math.max(0, unreadCount - 1));
    } catch (e) {
      message.error('操作失败');
    }
  };

  const handleMarkAllAsRead = async () => {
    try {
      await notificationAPI.markAllAsRead();
      setNotifications(prev => prev.map(n => ({ ...n, is_read: 1, read_at: new Date().toISOString() })));
      setUnreadCount(0);
      setUnreadByType({});
      message.success('全部已读');
    } catch (e) {
      message.error('操作失败');
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await notificationAPI.deleteNotification(id);
      setNotifications(prev => prev.filter(n => n.id !== id));
      if (!notifications.find(n => n.id === id)?.is_read) {
        setUnreadCount(Math.max(0, unreadCount - 1));
      }
    } catch (e) {
      message.error('删除失败');
    }
  };

  const handleClearRead = async () => {
    try {
      await notificationAPI.clearReadNotifications();
      setNotifications(prev => prev.filter(n => !n.is_read));
      message.success('已清空已读通知');
    } catch (e) {
      message.error('清空失败');
    }
  };

  const formatTime = (timeStr: string) => {
    if (!timeStr) return '';
    const date = new Date(timeStr);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMin = Math.floor(diffMs / 60000);

    if (diffMin < 1) return '刚刚';
    if (diffMin < 60) return `${diffMin}分钟前`;
    const diffHour = Math.floor(diffMin / 60);
    if (diffHour < 24) return `${diffHour}小时前`;
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  if (!isAuthenticated) {
    return (
      <Card style={{ borderRadius: 12, textAlign: 'center', padding: 40 }}>
        <Empty description="登录后查看通知" />
      </Card>
    );
  }

  const tabItems = isAdmin
    ? [
        { key: 'all', label: `全部 ${unreadCount > 0 ? `(${unreadCount})` : ''}` },
        { key: 'system', label: `系统 ${unreadByType.system || ''}`.trim() || '系统' },
        { key: 'forum_reply', label: `论坛 ${unreadByType.forum_reply || ''}`.trim() || '论坛' },
        { key: 'answer_changed', label: `答案更正 ${unreadByType.answer_changed || ''}`.trim() || '答案更正' },
      ]
    : isTeacher
    ? [
        { key: 'all', label: `全部 ${unreadCount > 0 ? `(${unreadCount})` : ''}` },
        { key: 'system', label: `系统 ${unreadByType.system || ''}`.trim() || '系统' },
        { key: 'class_join_request', label: `班级加入 ${unreadByType.class_join_request || ''}`.trim() || '班级加入' },
        { key: 'friend_request', label: `好友 ${unreadByType.friend_request || ''}`.trim() || '好友' },
        { key: 'forum_reply', label: `论坛 ${unreadByType.forum_reply || ''}`.trim() || '论坛' },
      ]
    : [
        { key: 'all', label: `全部 ${unreadCount > 0 ? `(${unreadCount})` : ''}` },
        { key: 'friend_request', label: `好友 ${unreadByType.friend_request || ''}`.trim() || '好友' },
        { key: 'gift_received', label: `礼物 ${unreadByType.gift_received || ''}`.trim() || '礼物' },
        { key: 'achievement', label: `成就 ${unreadByType.achievement || ''}`.trim() || '成就' },
        { key: 'post_like', label: `赞 ${unreadByType.post_like || ''}`.trim() || '赞' },
        { key: 'forum_reply', label: `论坛 ${unreadByType.forum_reply || ''}`.trim() || '论坛' },
        { key: 'answer_changed', label: `答案更正 ${unreadByType.answer_changed || ''}`.trim() || '答案更正' },
      ];

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: isMobile ? 12 : 20, flexWrap: 'wrap', gap: 8 }}>
        <h2 style={{ margin: 0, fontSize: isMobile ? 18 : undefined }}>
          <Badge count={unreadCount} size="small">
            <BellOutlined style={{ marginRight: isMobile ? 4 : 8 }} />
          </Badge>
          通知中心
        </h2>
        <Space size={isMobile ? 4 : 8} wrap>
          {unreadCount > 0 && (
            <Button size={isMobile ? 'small' : 'small'} onClick={handleMarkAllAsRead}>
              全部已读
            </Button>
          )}
          <Button size={isMobile ? 'small' : 'small'} onClick={handleClearRead}>
            清空已读
          </Button>
        </Space>
      </div>

      <Card styles={{ body: { padding: 0 } }} style={{ borderRadius: 12 }}>
        <Tabs
          activeKey={activeTab}
          onChange={(k) => setActiveTab(k)}
          items={tabItems}
          size="small"
          style={{ paddingLeft: isMobile ? 10 : 16 }}
          centered={isMobile}
        />

        <Spin spinning={loading}>
          {notifications.length === 0 ? (
            <Empty description="暂无通知" style={{ padding: isMobile ? 30 : 40 }} />
          ) : (
            <List
              dataSource={notifications}
              renderItem={(notif: NotificationItem) => {
                const config = typeConfig[notif.type] || { icon: <NotificationOutlined />, color: 'default', label: notif.type };
                return (
                  <List.Item
                    style={{
                      background: notif.is_read ? 'transparent' : '#f6ffed',
                      borderBottom: '1px solid #f5f5f5',
                      padding: isMobile ? '10px 14px' : '14px 20px',
                      cursor: notif.is_read ? 'default' : 'pointer',
                    }}
                    actions={[
                      !notif.is_read && (
                        <Button
                          type="link"
                          size="small"
                          icon={<CheckOutlined />}
                          onClick={() => handleMarkAsRead(notif.id)}
                          style={{ fontSize: isMobile ? 11 : undefined }}
                        >
                          {isMobile ? '' : '已读'}
                        </Button>
                      ),
                      <Popconfirm
                        title="确定删除此通知？"
                        onConfirm={() => handleDelete(notif.id)}
                        okText="确定"
                        cancelText="取消"
                      >
                        <Button type="link" danger size="small" icon={<DeleteOutlined />} style={{ fontSize: isMobile ? 11 : undefined }}>
                          {isMobile ? '' : '删除'}
                        </Button>
                      </Popconfirm>,
                    ]}
                    onClick={() => !notif.is_read && handleMarkAsRead(notif.id)}
                  >
                    <List.Item.Meta
                      avatar={
                        <div
                          style={{
                            width: isMobile ? 36 : 42,
                            height: isMobile ? 36 : 42,
                            borderRadius: '50%',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            background: notif.is_read ? '#f5f5f5' : '#e6f7ff',
                            fontSize: isMobile ? 16 : 18,
                            flexShrink: 0,
                          }}
                        >
                          {config.icon}
                        </div>
                      }
                      title={
                        <Space size={isMobile ? 4 : 6} wrap>
                          <span style={{ fontWeight: notif.is_read ? 400 : 600, fontSize: isMobile ? 13 : undefined }}>{notif.title}</span>
                          {!notif.is_read && <Badge status="processing" />}
                          <Tag color={config.color} style={{ fontSize: isMobile ? 9 : 10, margin: 0 }}>{config.label}</Tag>
                        </Space>
                      }
                      description={
                        <div>
                          {notif.content && (
                            <p style={{ margin: '4px 0 2px', color: '#666', lineHeight: 1.5, fontSize: isMobile ? 12 : 13 }}>
                              {notif.content}
                            </p>
                          )}
                          <span style={{ fontSize: isMobile ? 10 : 11, color: '#bbb' }}>{formatTime(notif.created_at)}</span>
                        </div>
                      }
                    />
                  </List.Item>
                );
              }}
            />
          )}
        </Spin>
      </Card>
    </div>
  );
};

export default Notifications;
