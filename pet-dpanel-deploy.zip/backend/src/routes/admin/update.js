/**
 * 软件升级接口（挂在 /api/admin/system/update）
 * 全部接口仅管理员可用；前端轮询 /status 展示升级进度。
 */
const express = require('express');
const router = express.Router();
const { execFile } = require('child_process');
const { authenticateToken } = require('../../middleware/auth');
const { requireAdmin } = require('./_shared');
const updater = require('../../services/updater');
const { genTaskManager } = require('../../services/genTaskManager');
const { getCurrentVersion, getGitCommit, BACKEND_DIR } = require('../../utils/version');
const { detectRuntime } = require('../../utils/runtime');

// 运行环境信息（版本、部署方式、目录），管理后台首屏展示
router.get('/info', authenticateToken, requireAdmin, (req, res) => {
  try {
    res.json({
      version: getCurrentVersion(),
      commit: getGitCommit(),
      node: process.version,
      platform: process.platform,
      installDir: BACKEND_DIR,
      runtime: detectRuntime(),
      manifestUrl: updater.getManifestUrl(),
      state: updater.getState(),
    });
  } catch (error) {
    console.error('获取升级信息失败:', error);
    res.status(500).json({ error: '获取升级信息失败' });
  }
});

// 保存更新源地址（清单 manifest.json 的 URL）
router.put('/source', authenticateToken, requireAdmin, (req, res) => {
  try {
    const url = (req.body || {}).url || '';
    updater.setManifestUrl(url);
    res.json({ message: url ? '更新源已保存' : '已清空更新源', manifestUrl: updater.getManifestUrl() });
  } catch (error) {
    console.error('保存更新源失败:', error);
    res.status(500).json({ error: error.message });
  }
});

// 检查更新
router.post('/check', authenticateToken, requireAdmin, async (req, res) => {
  try {
    res.json(await updater.checkForUpdates());
  } catch (error) {
    console.error('检查更新失败:', error);
    res.status(500).json({ error: error.message });
  }
});

// 升级进度（前端每 1.5 秒轮询一次）
router.get('/status', authenticateToken, requireAdmin, (req, res) => {
  res.json(updater.getState());
});

// 执行升级
// 立即返回，进度靠已有的 GET /status 轮询。原先这里同步等到整个升级跑完，
// 前端得挂一条 15 分钟的长连接——网关 60s 必然切断，用户还会误以为失败。
router.post('/apply', authenticateToken, requireAdmin, (req, res) => {
  // 升级会覆盖 backend/src 下正在被使用的文件。若此时有人正在出题或跑报告，
  // 那批任务会被连带打断（内存态任务直接消失），这里提前挡住。
  const runningAiTasks = genTaskManager.countRunning();
  if (runningAiTasks > 0) {
    return res.status(409).json({
      error: `当前还有 ${runningAiTasks} 个 AI 任务在运行（出题/识别/报告），请等它们完成后再升级`,
    });
  }
  if (updater.getState().running) {
    return res.status(409).json({ error: '已有升级任务在进行中，请勿重复点击' });
  }

  const version = (req.body || {}).version || '';
  res.json({ started: true, message: '升级已开始，可在下方查看进度' });

  // 后台执行，不阻塞响应
  setImmediate(async () => {
    try {
      await updater.applyUpdate(version);
      updater.pruneDownloads();
    } catch (error) {
      console.error('执行升级失败:', error);
    }
  });
});

// 备份列表
router.get('/backups', authenticateToken, requireAdmin, (req, res) => {
  res.json({ backups: updater.listBackups() });
});

// 回滚到指定备份（同升级：立即返回，进度靠 GET /status 轮询）
router.post('/rollback', authenticateToken, requireAdmin, (req, res) => {
  const runningAiTasks = genTaskManager.countRunning();
  if (runningAiTasks > 0) {
    return res.status(409).json({
      error: `当前还有 ${runningAiTasks} 个 AI 任务在运行，请等它们完成后再回滚`,
    });
  }
  if (updater.getState().running) {
    return res.status(409).json({ error: '已有升级任务在进行中，请稍后' });
  }

  const file = (req.body || {}).file || '';
  res.json({ started: true, message: '回滚已开始，可在下方查看进度' });

  setImmediate(async () => {
    try {
      await updater.rollbackTo(file);
    } catch (error) {
      console.error('回滚失败:', error);
    }
  });
});

// 升级日志
router.get('/log', authenticateToken, requireAdmin, (req, res) => {
  res.json({ logs: updater.readLog(30) });
});

// 重启服务：仅在检测到 PM2 托管时允许（裸机/无托管时不做自杀式重启，只返回命令）
router.post('/restart', authenticateToken, requireAdmin, (req, res) => {
  const runtime = detectRuntime();
  if (!runtime.canSelfRestart) {
    return res.status(400).json({
      error: '当前部署方式不支持一键重启，请手动执行：' + runtime.restartCommand,
      runtime,
    });
  }
  const name = String(runtime.restartCommand || '').replace('pm2 restart ', '').trim();
  execFile('pm2', ['restart', name], { timeout: 20000 }, (error, stdout, stderr) => {
    if (error) {
      console.error('pm2 重启失败:', error.message, stderr || '');
      return res.status(500).json({ error: '重启失败：' + (stderr || error.message) });
    }
    res.json({ message: '服务正在重启，页面稍后会自动刷新', runtime });
  });
});

module.exports = router;
