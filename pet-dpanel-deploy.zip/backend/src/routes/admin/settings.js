const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const { db } = require('../../config/database');
const { authenticateToken } = require('../../middleware/auth');
const { getChinaDate } = require('../../config/timezone');
const { getAIConfig, isAIConfigured, getAITimeoutMs } = require('../../config/ai');
const { PROMPTS, SETTING_PREFIX, getPrompt, fillTemplate } = require('../../config/prompts');
const { chatCompletion } = require('../../services/aiClient');
const {
  USERNAME_MAX_LEN,
  AI_USERNAME_BATCH_SIZE,
  requireAdmin,
  purgeUserData,
  applyApplicationToClass,
  approveTeacherPendingApplications,
  checkDataPermission,
  cleanStudentNames,
  findDuplicateNames,
  sanitizeUsername,
  sanitizeSequencePrefix,
  isUsernameTaken,
  ensureUniqueUsername,
  randomPassword,
  parseJSONArray,
  generateUsernamesByAI,
  ensureSettingsTable,
} = require('./_shared');
const { FLAG_KEYS, getPublicFlags, ensureFlags } = require('../../middleware/featureFlags');

router.get('/settings/ai', authenticateToken, requireAdmin, (req, res) => {
  try {
    const hasTable = db.prepare(`SELECT name FROM sqlite_master WHERE type='table' AND name='settings'`).get();
    if (!hasTable) {
      db.prepare(`
        CREATE TABLE settings (
          key TEXT PRIMARY KEY,
          value TEXT NOT NULL
        )
      `).run();
      db.prepare(`INSERT INTO settings (key, value) VALUES ('ai_model', 'gpt-3.5-turbo')`).run();
      db.prepare(`INSERT INTO settings (key, value) VALUES ('ai_api_key', '')`).run();
      db.prepare(`INSERT INTO settings (key, value) VALUES ('ai_base_url', 'https://api.openai.com/v1')`).run();
    }
    
    // AI设置页既有连接类字段（ai_*），也有「生成限制」里的数字参数
    // （max_tokens_per_generation / daily_teacher_gen_limit 等）。
    // 后者不以 ai_ 开头，用 `LIKE 'ai_%'` 会漏掉，导致页面上填的数又变回默认值。
    const AI_SETTING_KEYS = [
      'ai_model', 'ai_api_key', 'ai_base_url', 'ai_report_interval_days', 'ai_timeout', 'ai_vision_model',
      'max_tokens_per_generation', 'daily_teacher_gen_limit', 'ai_gen_max_rounds',
      'daily_global_token_limit', 'max_questions_per_generation', 'ai_gen_concurrency',
    ];
    const placeholders = AI_SETTING_KEYS.map(() => '?').join(',');
    const settings = db.prepare(`SELECT key, value FROM settings WHERE key IN (${placeholders})`).all(...AI_SETTING_KEYS);
    const result = {};
    settings.forEach(s => result[s.key] = s.value);
    // 只写不读：不暴露 API Key 到前端
    if (result.ai_api_key && result.ai_api_key.length > 0) {
      result.ai_api_key = '***';
    }
    res.json({ settings: result });
  } catch (error) {
    console.error('获取设置失败:', error);
    res.status(500).json({ error: '获取设置失败' });
  }
});

router.post('/settings/ai', authenticateToken, requireAdmin, (req, res) => {
  try {
    // 原先这里只解构并保存 6 个字段，而页面上有 11 个输入框——
    // 「生成限制」那几项填了会被静默丢弃，且没有任何提示。
    // 现按白名单逐项落库：文本类原样存，数字类校验范围后存。
    const TEXT_KEYS = ['ai_model', 'ai_base_url', 'ai_vision_model'];
    // key -> [最小值, 最大值]，防止手改请求体写入 0 或超大值把生成功能搞坏
    const INT_KEYS = {
      ai_report_interval_days: [0, 365],
      ai_timeout: [10, 1800],
      max_tokens_per_generation: [1000, 200000],
      daily_teacher_gen_limit: [1, 200],
      ai_gen_max_rounds: [1, 10],
      daily_global_token_limit: [10000, 100000000],
      max_questions_per_generation: [1, 100],
      ai_gen_concurrency: [1, 8],
      // 思考预算：0 表示不限制（由模型自行决定），上限 200k 与输出口径对齐
      ai_thinking_budget: [0, 200000],
    };

    // 枚举类字段：只接受白名单取值，避免手改请求体写入非法值导致 AI 调用一直失败
    const ENUM_KEYS = {
      ai_api_mode: ['chat', 'responses'],
      ai_thinking_effort: ['low', 'medium', 'high'],
      ai_thinking_summary: ['', 'auto', 'concise', 'detailed'],
      // 开关类存 'true'/'false' 字符串
      ai_thinking_enabled: ['true', 'false'],
    };

    const stmt = db.prepare(`INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)`);
    const rejected = [];
    db.transaction(() => {
      for (const key of TEXT_KEYS) {
        if (req.body[key] !== undefined) stmt.run(key, String(req.body[key]));
      }
      for (const [key, [min, max]] of Object.entries(INT_KEYS)) {
        if (req.body[key] === undefined || req.body[key] === '') continue;
        const n = parseInt(req.body[key], 10);
        if (!Number.isFinite(n) || n < min || n > max) {
          rejected.push(key);
          continue;
        }
        stmt.run(key, String(n));
      }
      for (const [key, allowed] of Object.entries(ENUM_KEYS)) {
        if (req.body[key] === undefined) continue;
        const v = String(req.body[key]);
        if (!allowed.includes(v)) {
          rejected.push(key);
          continue;
        }
        stmt.run(key, v);
      }
      // API Key 只写不读：仅在用户明确提供真实值时更新
      if (req.body.ai_api_key !== undefined && req.body.ai_api_key !== '' && req.body.ai_api_key !== '***') {
        stmt.run('ai_api_key', req.body.ai_api_key);
      }
    })();

    res.json({
      message: rejected.length > 0 ? `部分设置超出允许范围未保存：${rejected.join('、')}` : '设置保存成功',
      rejected,
    });
  } catch (error) {
    console.error('保存设置失败:', error);
    res.status(500).json({ error: '保存设置失败' });
  }
});

router.get('/settings/prompts', authenticateToken, requireAdmin, (req, res) => {
  try {
    ensureSettingsTable();
    const rows = db.prepare(`SELECT key, value FROM settings WHERE key LIKE ?`).all(SETTING_PREFIX + '%');
    const customMap = {};
    rows.forEach(r => { customMap[r.key.slice(SETTING_PREFIX.length)] = r.value; });

    const prompts = Object.entries(PROMPTS).map(([key, def]) => {
      const custom = customMap[key];
      const isCustom = custom !== undefined && String(custom).trim() !== '' && String(custom) !== def.default;
      return {
        key,
        group: def.group,
        label: def.label,
        description: def.description,
        value: isCustom ? custom : def.default,
        is_custom: isCustom,
        has_custom: custom !== undefined && String(custom).trim() !== ''
      };
    });

    res.json({ prompts });
  } catch (error) {
    console.error('获取提示词设置失败:', error);
    res.status(500).json({ error: '获取提示词设置失败' });
  }
});

router.post('/settings/prompts', authenticateToken, requireAdmin, (req, res) => {
  try {
    ensureSettingsTable();
    const updates = req.body?.prompts;
    if (!updates || typeof updates !== 'object') {
      return res.status(400).json({ error: '参数错误' });
    }

    const stmt = db.prepare(`INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)`);
    const del = db.prepare(`DELETE FROM settings WHERE key = ?`);
    db.transaction(() => {
      for (const [key, value] of Object.entries(updates)) {
        if (!PROMPTS[key]) continue; // 忽略未注册的提示词
        const v = String(value ?? '');
        if (v.trim() === '' || v === PROMPTS[key].default) {
          del.run(SETTING_PREFIX + key);
        } else {
          stmt.run(SETTING_PREFIX + key, v);
        }
      }
    })();

    res.json({ message: '提示词保存成功' });
  } catch (error) {
    console.error('保存提示词设置失败:', error);
    res.status(500).json({ error: '保存提示词设置失败' });
  }
});

router.post('/settings/prompts/reset', authenticateToken, requireAdmin, (req, res) => {
  try {
    ensureSettingsTable();
    const keys = Array.isArray(req.body?.keys) ? req.body.keys : Object.keys(PROMPTS);
    const del = db.prepare(`DELETE FROM settings WHERE key = ?`);
    db.transaction(() => {
      for (const key of keys) {
        if (PROMPTS[key]) del.run(SETTING_PREFIX + key);
      }
    })();

    res.json({ message: `已恢复 ${keys.length} 个提示词为默认值` });
  } catch (error) {
    console.error('恢复默认提示词失败:', error);
    res.status(500).json({ error: '恢复默认提示词失败' });
  }
});

router.post('/settings/ai/test', authenticateToken, requireAdmin, async (req, res) => {
  try {
    let { ai_model, ai_api_key, ai_base_url, ai_timeout, ai_api_mode } = req.body;

    ensureSettingsTable();

    // 思考模式默认跟随已保存的设置，也允许本次测试临时覆盖，
    // 这样管理员可以先试开启再决定要不要保存
    const savedRows = db.prepare(
      `SELECT key, value FROM settings WHERE key IN
       ('ai_api_mode','ai_thinking_enabled','ai_thinking_effort','ai_thinking_budget','ai_thinking_summary')`
    ).all();
    const saved = {};
    savedRows.forEach(r => { saved[r.key] = r.value; });

    if (!ai_api_mode) ai_api_mode = saved.ai_api_mode || 'chat';

    // 如果前端传了 *** 掩码，从数据库读取真实 key
    if (!ai_api_key || ai_api_key === '***') {
      const row = db.prepare(`SELECT value FROM settings WHERE key = 'ai_api_key'`).get();
      ai_api_key = row?.value || '';
    }

    if (!ai_model || !ai_api_key || !ai_base_url) {
      return res.status(400).json({ error: '请填写完整的 AI 配置' });
    }

    const timeoutMs = (parseInt(ai_timeout) || 300) * 1000;
    const mode = String(ai_api_mode).trim().toLowerCase() === 'responses' ? 'responses' : 'chat';

    console.log('\n========== AI 连接测试 ==========');
    console.log('🎯 目标地址:', `${ai_base_url}/${mode === 'responses' ? 'responses' : 'chat/completions'}`);
    console.log('🔌 接口协议:', mode === 'responses' ? 'Responses API' : 'Chat Completions API');
    console.log('🤖 使用模型:', ai_model);
    console.log('🔑 API Key:', `${ai_api_key.slice(0, 8)}...${ai_api_key.slice(-4)}`);
    console.log('⏱️ 超时设置:', timeoutMs / 1000, '秒');

    const startTime = Date.now();
    // 复用统一客户端：测试走的是与线上完全相同的协议适配与降级逻辑，
    // 否则「测试通过但实际调用失败」会误导管理员
    const reply = await chatCompletion({
      config: {
        ai_api_key,
        ai_base_url,
        ai_model,
        ai_api_mode: mode,
        ai_thinking_enabled: req.body.ai_thinking_enabled ?? saved.ai_thinking_enabled,
        ai_thinking_effort: req.body.ai_thinking_effort ?? saved.ai_thinking_effort,
        ai_thinking_budget: req.body.ai_thinking_budget ?? saved.ai_thinking_budget,
        ai_thinking_summary: req.body.ai_thinking_summary ?? saved.ai_thinking_summary,
      },
      prompt: '你好，请回复"连接成功"四个字。',
      timeoutMs,
      label: '连接测试',
      logger: (m) => console.log(m),
    });
    const elapsed = ((Date.now() - startTime) / 1000).toFixed(2);

    console.log('✅ AI 响应成功, 耗时:', elapsed, '秒');
    console.log('📄 AI 回复内容:', reply.content);
    console.log('========================================\n');

    res.json({
      success: true,
      message: reply.degraded ? '连接测试成功（部分参数不被支持，已自动降级）' : '连接测试成功',
      ai_reply: reply.content,
      elapsed: `${elapsed}秒`,
      model: ai_model,
      api_mode: mode,
      degraded: reply.degraded,
      usage: reply.usage,
    });
  } catch (error) {
    console.error('\n❌ AI 连接测试失败:', error.message);
    if (error.response) {
      console.error('📡 响应状态:', error.response.status);
      console.error('📡 响应数据:', JSON.stringify(error.response.data));
      res.status(500).json({
        error: `连接失败 (HTTP ${error.response.status})`,
        detail: error.response.data?.error?.message || JSON.stringify(error.response.data)
      });
    } else if (error.code === 'ECONNABORTED') {
      console.error('⏱️ 请求超时');
      res.status(500).json({ error: `请求超时 (${(parseInt(req.body.ai_timeout) || 300)}秒)`, detail: '请检查网络连接或 API 地址是否正确' });
    } else if (error.code === 'ECONNREFUSED') {
      console.error('🚫 连接被拒绝');
      res.status(500).json({ error: '连接被拒绝', detail: '请检查 API 地址是否正确' });
    } else {
      console.error('❌ 未知错误:', error);
      res.status(500).json({ error: '连接失败', detail: error.message });
    }
  }
});

router.get('/settings/site', authenticateToken, requireAdmin, (req, res) => {
  try {
    ensureSettingsTable();
    ensureFlags();
    const settings = db.prepare(`SELECT key, value FROM settings`).all();
    const result = {};
    settings.forEach(s => result[s.key] = s.value);
    // 开关补齐默认值，避免前端把「没有这个 key」误判成关闭
    Object.assign(result, getPublicFlags());
    // 只写不读：不暴露 API Key 到前端
    if (result.ai_api_key && result.ai_api_key.length > 0) {
      result.ai_api_key = '***';
    }
    res.json({ settings: result });
  } catch (error) {
    console.error('获取网站设置失败:', error);
    res.status(500).json({ error: '获取网站设置失败' });
  }
});

router.post('/settings/site', authenticateToken, requireAdmin, (req, res) => {
  try {
    ensureSettingsTable();
    ensureFlags();
    const allowedKeys = [
      'site_name', 'site_description', 'site_logo', 'site_footer',
      'site_announcement', 'home_notice',
      'max_pets_per_user', 'daily_login_gold', 'battle_stamina_cost',
      'ai_model', 'ai_api_key', 'ai_base_url',
      'ai_report_interval_days', 'ai_timeout',
      // 视觉模型：原先不在白名单里，导致「AI设置」页填写的视觉模型被静默丢弃
      'ai_vision_model',
      // 接口协议与思考模式：不在白名单里会导致「AI设置」页的填写被静默丢弃
      'ai_api_mode', 'ai_thinking_enabled', 'ai_thinking_effort',
      'ai_thinking_budget', 'ai_thinking_summary',
      'perm_battle_records', 'perm_homework_records', 'perm_purchase_records',
      'max_tokens_per_generation', 'daily_teacher_gen_limit',
      'daily_global_token_limit', 'max_questions_per_generation',
      // AI 出题的最大轮次：题量偏多时会自动分多轮续写补齐
      'ai_gen_max_rounds',
      // 多题型同时生成的并发数：串行时多种题型会累加到几百秒，容易撞上网关超时
      'ai_gen_concurrency',
      // 功能开关统一由 featureFlags 提供清单，避免两处各维护一份而漏项
      ...FLAG_KEYS,
    ];
    // 开关只接受 true / false，其它值一律忽略，防止手改请求体写入脏值
    const flagSet = new Set(FLAG_KEYS);
    const stmt = db.prepare(`INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)`);
    db.transaction(() => {
      Object.entries(req.body).forEach(([key, value]) => {
        if (allowedKeys.includes(key)) {
          // API Key 只写不读：仅在用户明确提供真实值时更新
          if (key === 'ai_api_key') {
            if (value !== undefined && value !== '' && value !== '***') {
              stmt.run(key, String(value));
            }
            return;
          }
          if (flagSet.has(key)) {
            const v = String(value);
            if (v === 'true' || v === 'false') stmt.run(key, v);
            return;
          }
          stmt.run(key, String(value));
        }
      });
    })();
    res.json({ message: '设置保存成功' });
  } catch (error) {
    console.error('保存网站设置失败:', error);
    res.status(500).json({ error: '保存网站设置失败' });
  }
});

router.get('/settings/public', (req, res) => {
  try {
    ensureSettingsTable();
    const publicKeys = ['site_name', 'site_description', 'site_logo', 'site_footer', 'site_announcement', 'home_notice'];
    const settings = db.prepare(`SELECT key, value FROM settings WHERE key IN (${publicKeys.map(() => '?').join(',')})`).all(...publicKeys);
    const result = {};
    settings.forEach(s => result[s.key] = s.value);
    // 下发全部功能开关（已按默认值补齐）：前端据此隐藏菜单/页签/注册入口。
    // 这些都是布尔运营配置，不涉及敏感信息；真正的前后端拦截仍在后端做。
    Object.assign(result, getPublicFlags());
    res.json({ settings: result });
  } catch (error) {
    console.error('获取公开设置失败:', error);
    res.status(500).json({ error: '获取设置失败' });
  }
});

module.exports = router;
