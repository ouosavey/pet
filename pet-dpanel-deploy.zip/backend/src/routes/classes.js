const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { db } = require('../config/database');
const { authenticateToken, optionalAuth } = require('../middleware/auth');
const crypto = require('crypto');
const { isValidSlug, generateClassSlug } = require('../utils/slug');
const { getHeadTeachers, getHeadTeacherClasses } = require('../utils/headTeacher');
const { notifyClassMemberJoined } = require('../services/joinNotify');
const { isFeatureEnabled, requireFeature } = require('../middleware/featureFlags');

// 生成推荐码
function generateInviteCode() {
  return crypto.randomBytes(4).toString('hex').toUpperCase();
}

router.get('/public-list', (req, res) => {
  try {
    // 关闭站点级「班级公开」后，未登录访客不应再看到任何班级名单
    if (!isFeatureEnabled('class_public_enabled')) return res.json({ classes: [] });
    const classes = db.prepare(`
      SELECT c.id, c.name, c.grade, c.slug, c.school_id,
        s.name AS school_name,
        CASE WHEN c.head_teacher_id IS NOT NULL
          OR EXISTS (SELECT 1 FROM class_teachers ct WHERE ct.class_id = c.id AND ct.role = 'head_teacher')
          THEN 1 ELSE 0 END AS has_head_teacher,
        (SELECT COUNT(*) FROM users WHERE class_id = c.id AND role = 'student') as student_count
      FROM classes c
      LEFT JOIN schools s ON c.school_id = s.id
      WHERE COALESCE(c.is_public, 1) = 1
      ORDER BY c.created_at DESC
    `).all();
    res.json({ classes });
  } catch (error) {
    console.error('获取公开班级列表失败:', error);
    res.status(500).json({ error: '获取班级列表失败' });
  }
});

// 通过 slug 获取班级公开主页信息（未登录也可访问，若 is_public=0 则 404）
router.get('/by-slug/:slug', (req, res) => {
  try {
    // 站点级开关关闭时，统一按「不存在」处理，不暴露班级是否真实存在
    if (!isFeatureEnabled('class_public_enabled')) {
      return res.status(404).json({ error: '班级不存在' });
    }
    const { slug } = req.params;
    const cls = db.prepare(`
      SELECT c.id, c.name, c.grade, c.slug, c.description, c.cover_image,
             c.is_public, c.school_id, c.created_at, c.head_teacher_id,
             s.name AS school_name, s.theme_color AS school_theme,
             COALESCE(u.real_name, u.username) AS head_teacher_name, u.avatar AS head_teacher_avatar,
             (SELECT COUNT(*) FROM users WHERE class_id = c.id AND role = 'student') AS student_count,
             (SELECT COUNT(*) FROM class_teachers WHERE class_id = c.id) AS teacher_count
      FROM classes c
      LEFT JOIN schools s ON c.school_id = s.id
      LEFT JOIN users u ON c.head_teacher_id = u.id
      WHERE c.slug = ?
    `).get(slug);

    if (!cls) return res.status(404).json({ error: '班级不存在' });
    if (!cls.is_public) return res.status(404).json({ error: '班级不存在或未公开' });

    // 公开 BOSS 进度（如有）
    const activeBoss = db.prepare(`
      SELECT id, boss_name, boss_icon, boss_max_hp, started_at
      FROM boss_battles WHERE class_id = ? AND status = 'active' LIMIT 1
    `).get(cls.id);
    let bossProgress = null;
    if (activeBoss) {
      const totalDamage = db.prepare(`
        SELECT COALESCE(SUM(damage_dealt), 0) AS total FROM boss_battle_participants WHERE boss_battle_id = ?
      `).get(activeBoss.id).total || 0;
      bossProgress = {
        ...activeBoss,
        total_damage: totalDamage,
        progress: Math.min(100, Math.round((totalDamage / activeBoss.boss_max_hp) * 100))
      };
    }

    // 安全：本接口未登录即可访问，绝不能返回邀请码。
    // 原先会把一个有效邀请码直接暴露给任意访客，任何人都能拿它免审批注册进班。
    res.json({
      class: cls,
      // 一个班可有多位班主任；class.head_teacher_* 仅为兼容字段，指向主班主任
      head_teachers: getHeadTeachers(cls.id),
      active_boss: bossProgress
    });
  } catch (error) {
    console.error('获取班级公开主页失败:', error);
    res.status(500).json({ error: '获取班级公开主页失败' });
  }
});

/**
 * 升级所需经验：与前端宠物面板（PetDisplay）用的是同一条公式，
 * 保证「累计积分」在任何页面算出来都是同一个数。
 */
function expToNext(level) {
  return Math.floor(100 * Math.pow(level, 1.5));
}

/**
 * 累计积分 = 当前等级已攒的经验 + 前面每一级的满级经验之和。
 *
 * pets.total_exp_earned 列在建表后就没人维护过（库里全是 0），
 * 直接展示会满屏 0 看着像坏了，所以按等级现场折算，不依赖那列。
 */
function totalExpOf(pet) {
  let sum = Number(pet.exp) || 0;
  for (let lv = 1; lv < (Number(pet.level) || 1); lv += 1) sum += expToNext(lv);
  return sum;
}

/**
 * 姓名脱敏：保留首字，其余打码。
 * 访客看班级宠物时主人名必须脱敏——学生是未成年人，真名不能进公开接口；
 * 但完全不显示又会让「谁的宠物」这件事失去意义，所以保留姓氏首字。
 */
function maskOwnerName(name) {
  const chars = Array.from(String(name || '').trim());
  if (chars.length === 0) return '神秘同学';
  if (chars.length === 1) return `${chars[0]}*`;
  return `${chars[0]}${'*'.repeat(Math.min(chars.length - 1, 3))}`;
}

/**
 * 班级宠物列表（/c/:slug/pets 页面用，**未登录也可访问**）
 *
 * 为什么单独开一个接口而不是复用 /api/pets/all：
 *   /all 强制登录且要求是本班成员，访客点开班级主页就只能看到空白区块；
 *   而「班级养了多少宠物、养得怎么样」恰恰是最适合对外展示的东西。
 *
 * 分级可见（用 optionalAuth 判定身份，token 无效则按访客处理）：
 *   本班学生 / 本班任课教师 / 管理员 → 主人真名 + 用户名
 *   访客                              → 主人名脱敏成「张*」，不给用户名
 * 金币按需求暂时对访客可见（后续要收口时改这里即可，前端不用动）。
 */
router.get('/by-slug/:slug/pets', optionalAuth, (req, res) => {
  try {
    if (!isFeatureEnabled('class_public_enabled')) {
      return res.status(404).json({ error: '班级不存在' });
    }
    const { slug } = req.params;
    const cls = db
      .prepare(
        `SELECT c.id, c.name, c.grade, c.slug, c.school_id,
                COALESCE(c.is_public, 1) AS is_public,
                s.name AS school_name, s.theme_color AS school_theme,
                (SELECT COUNT(*) FROM users u WHERE u.class_id = c.id AND u.role = 'student') AS student_count,
                (SELECT GROUP_CONCAT(COALESCE(u2.real_name, u2.username), char(31))
                   FROM class_teachers ct2 JOIN users u2 ON u2.id = ct2.teacher_id
                  WHERE ct2.class_id = c.id AND ct2.role = 'head_teacher') AS head_teacher_names
         FROM classes c
         LEFT JOIN schools s ON s.id = c.school_id
         WHERE c.slug = ?`
      )
      .get(slug);
    if (!cls) return res.status(404).json({ error: '班级不存在' });
    if (!cls.is_public) return res.status(404).json({ error: '班级不存在或未公开' });

    // 成员判定：本班学生 / 本班教师 / 管理员
    let isMember = false;
    if (req.user && req.user.userId) {
      if (req.user.role === 'admin') {
        isMember = true;
      } else {
        const asStudent = db
          .prepare(`SELECT 1 FROM users WHERE id = ? AND class_id = ?`)
          .get(req.user.userId, cls.id);
        const asTeacher = db
          .prepare(`SELECT 1 FROM class_teachers WHERE teacher_id = ? AND class_id = ?`)
          .get(req.user.userId, cls.id);
        isMember = Boolean(asStudent || asTeacher);
      }
    }

    const pets = db
      .prepare(
        `SELECT p.id, p.name AS pet_name, p.level, p.exp, p.total_exp_earned,
                p.hunger, p.mood, p.health, p.stamina,
                p.attack, p.defense, p.speed, p.growth_stage, p.status,
                p.win_count, p.total_battles, p.friendship_points, p.created_at,
                ps.name AS species_name, ps.element_type, ps.image_urls,
                u.id AS user_id,
                COALESCE(u.real_name, u.username) AS owner_name,
                u.username AS owner_username,
                u.gold AS gold
         FROM pets p
         JOIN pet_species ps ON p.species_id = ps.id
         JOIN users u ON p.user_id = u.id
         WHERE u.class_id = ? AND u.role = 'student'
         ORDER BY p.level DESC, p.exp DESC`
      )
      .all(cls.id)
      .map((p) => ({
        ...p,
        total_exp: totalExpOf(p),
        // 升级进度：前端拿到的就是百分比，省得每个页面各算一遍
        exp_progress: Math.min(
          100,
          Math.round(((Number(p.exp) || 0) / expToNext(Number(p.level) || 1)) * 100)
        ),
        owner_name: isMember ? p.owner_name : maskOwnerName(p.owner_name),
        owner_username: isMember ? p.owner_username : null,
        /**
         * 金币对访客隐藏：主人名已经脱敏成「张*」了，再把每个学生的金币余额
         * 摆在免登录页上，等于公开「谁家孩子有多少钱」。
         * 与 public.js 的隐私红线保持一致（那边的 total_gold 已摘掉）。
         * 非成员一律给 null，前端据此不渲染。
         */
        gold: isMember ? (Number(p.gold) || 0) : null,
      }));

    // 顶部汇总：老师最关心的是「全班养得怎么样 + 有几只需要照顾」
    const stats = {
      pet_count: pets.length,
      student_count: cls.student_count || 0,
      avg_level:
        pets.length > 0
          ? Math.round((pets.reduce((s, p) => s + (p.level || 0), 0) / pets.length) * 10) / 10
          : 0,
      max_level: pets.reduce((m, p) => Math.max(m, p.level || 0), 0),
      total_exp: pets.reduce((s, p) => s + (p.total_exp || 0), 0),
      // 同样只对成员给：访客看到的是「这个班养得怎么样」，不是「这个班有多少钱」
      total_gold: isMember ? pets.reduce((s, p) => s + (p.gold || 0), 0) : null,
      unconscious_count: pets.filter((p) => p.status === 'unconscious').length,
      // 体力/健康低于 30 视为「需要照顾」，与前端宠物面板的告警阈值保持一致
      need_care_count: pets.filter(
        (p) => (p.stamina ?? 100) < 30 || (p.health ?? 100) < 30 || (p.hunger ?? 100) < 30
      ).length,
    };

    res.json({
      class: {
        id: cls.id,
        name: cls.name,
        grade: cls.grade,
        slug: cls.slug,
        school_id: cls.school_id,
        school_name: cls.school_name,
        school_theme: cls.school_theme,
        student_count: cls.student_count || 0,
        head_teacher_names: cls.head_teacher_names
          // 用 ASCII 单元分隔符（char(31)）而不是默认逗号：
          // 老师姓名里本来就可能有逗号（「张,三」这种少见但合法的姓名），
          // 按逗号拆会把一个人劈成两半，页面上多出一位根本不存在的班主任。
          // 与 routes/public.js 的班级广场同一口径。
          ? String(cls.head_teacher_names).split('\u001f').filter(Boolean)
          : [],
      },
      is_member: isMember,
      stats,
      pets,
    });
  } catch (error) {
    console.error('获取班级宠物列表失败:', error);
    res.status(500).json({ error: '获取班级宠物列表失败' });
  }
});

// 班级主页聚合数据（登录 + 本班成员可用）
router.get('/:id/home-summary', authenticateToken, (req, res) => {
  try {
    const classId = parseInt(req.params.id, 10);
    if (!classId) return res.status(400).json({ error: '班级 ID 无效' });

    // 权限：班级成员或管理员
    if (req.user.role !== 'admin') {
      const asStudent = db.prepare(`SELECT 1 FROM users WHERE id = ? AND class_id = ?`).get(req.user.userId, classId);
      const asTeacher = db.prepare(`SELECT 1 FROM class_teachers WHERE teacher_id = ? AND class_id = ?`).get(req.user.userId, classId);
      if (!asStudent && !asTeacher) {
        return res.status(403).json({ error: '无权访问该班级' });
      }
    }

    const cls = db.prepare(`
      SELECT c.id, c.name, c.grade, c.slug, c.description, c.cover_image, c.is_public,
             c.school_id, COALESCE(u.real_name, u.username) AS head_teacher_name, u.id AS head_teacher_id,
             s.name AS school_name, s.theme_color AS school_theme
      FROM classes c
      LEFT JOIN users u ON c.head_teacher_id = u.id
      LEFT JOIN schools s ON c.school_id = s.id
      WHERE c.id = ?
    `).get(classId);
    if (!cls) return res.status(404).json({ error: '班级不存在' });

    const studentCount = db.prepare(`SELECT COUNT(*) AS c FROM users WHERE class_id = ? AND role = 'student'`).get(classId).c;
    const teachers = db.prepare(`
      SELECT u.id, u.username, u.real_name, u.avatar, ct.role
      FROM class_teachers ct JOIN users u ON ct.teacher_id = u.id
      WHERE ct.class_id = ?
      ORDER BY CASE ct.role WHEN 'head_teacher' THEN 0 ELSE 1 END, ct.created_at ASC
    `).all(classId);

    // Top10 班级等级榜
    const topPets = db.prepare(`
      SELECT p.id, p.name, p.level, p.exp, ps.name AS species_name, ps.image_urls,
             COALESCE(u.real_name, u.username) AS owner_name, u.id AS user_id
      FROM pets p
      JOIN pet_species ps ON p.species_id = ps.id
      JOIN users u ON p.user_id = u.id
      WHERE u.class_id = ? AND u.role = 'student'
      ORDER BY p.level DESC, p.exp DESC
      LIMIT 10
    `).all(classId);

    // 最新公告
    let announcements = [];
    try {
      announcements = db.prepare(`
        SELECT id, title, content, priority, created_at
        FROM announcements WHERE class_id = ?
          AND (expires_at IS NULL OR expires_at > datetime('now'))
        ORDER BY priority DESC, created_at DESC LIMIT 5
      `).all(classId);
    } catch (e) { /* 表或字段不存在时容错 */ }

    // 当前 BOSS
    let activeBoss = null;
    try {
      activeBoss = db.prepare(`
        SELECT id, boss_name, boss_icon, boss_max_hp, boss_level, knowledge_point, started_at, expires_at
        FROM boss_battles WHERE class_id = ? AND status = 'active' LIMIT 1
      `).get(classId);
      if (activeBoss) {
        const totalDamage = db.prepare(`
          SELECT COALESCE(SUM(damage_dealt), 0) AS total FROM boss_battle_participants WHERE boss_battle_id = ?
        `).get(activeBoss.id).total || 0;
        activeBoss.total_damage = totalDamage;
        activeBoss.progress = Math.min(100, Math.round((totalDamage / activeBoss.boss_max_hp) * 100));
      }
    } catch (e) { /* 容错 */ }

    // 最新动态
    let recentPosts = [];
    try {
      recentPosts = db.prepare(`
        SELECT p.id, p.content, p.created_at, u.username, u.real_name, u.avatar
        FROM posts p JOIN users u ON p.user_id = u.id
        WHERE p.class_id = ?
        ORDER BY p.created_at DESC LIMIT 5
      `).all(classId);
    } catch (e) { /* 容错 */ }

    res.json({
      class: cls,
      student_count: studentCount,
      teachers,
      head_teachers: teachers.filter((t) => t.role === 'head_teacher'),
      top_pets: topPets,
      announcements,
      active_boss: activeBoss,
      recent_posts: recentPosts
    });
  } catch (error) {
    console.error('获取班级主页聚合失败:', error);
    res.status(500).json({ error: '获取班级主页数据失败' });
  }
});

// 班主任自定义 slug（班级短标识）
router.put('/:id/slug', authenticateToken, (req, res) => {
  try {
    const classId = parseInt(req.params.id, 10);
    if (!classId) return res.status(400).json({ error: '班级 ID 无效' });
    const { slug } = req.body || {};
    const s = String(slug || '').trim();
    if (!isValidSlug(s)) {
      return res.status(400).json({ error: 'slug 需 3-64 位中文/字母/数字/连字符，且首尾为中文、字母或数字' });
    }
    if (req.user.role !== 'admin') {
      const row = db.prepare(
        `SELECT 1 FROM class_teachers WHERE teacher_id = ? AND class_id = ? AND role = 'head_teacher'`
      ).get(req.user.userId, classId);
      if (!row) return res.status(403).json({ error: '仅班主任可修改班级标识' });
    }
    const exists = db.prepare(`SELECT id FROM classes WHERE id = ?`).get(classId);
    if (!exists) return res.status(404).json({ error: '班级不存在' });
    const dup = db.prepare(`SELECT id FROM classes WHERE slug = ? AND id <> ?`).get(s, classId);
    if (dup) return res.status(400).json({ error: '该 slug 已被占用' });
    db.prepare(`UPDATE classes SET slug = ? WHERE id = ?`).run(s, classId);
    res.json({ message: '班级标识更新成功', slug: s });
  } catch (error) {
    console.error('更新班级 slug 失败:', error);
    res.status(500).json({ error: '更新班级标识失败' });
  }
});

// 班级基础设置（班主任可改）：description、cover_image、is_public
router.put('/:id/settings', authenticateToken, (req, res) => {
  try {
    const classId = parseInt(req.params.id, 10);
    if (!classId) return res.status(400).json({ error: '班级 ID 无效' });
    if (req.user.role !== 'admin') {
      const row = db.prepare(
        `SELECT 1 FROM class_teachers WHERE teacher_id = ? AND class_id = ? AND role = 'head_teacher'`
      ).get(req.user.userId, classId);
      if (!row) return res.status(403).json({ error: '仅班主任可修改班级设置' });
    }
    const { description, cover_image, is_public } = req.body || {};
    const fields = [];
    const values = [];
    if (description !== undefined) { fields.push('description = ?'); values.push(description); }
    if (cover_image !== undefined) { fields.push('cover_image = ?'); values.push(cover_image); }
    if (is_public !== undefined) { fields.push('is_public = ?'); values.push(is_public ? 1 : 0); }
    if (!fields.length) return res.status(400).json({ error: '没有要更新的字段' });
    values.push(classId);
    db.prepare(`UPDATE classes SET ${fields.join(', ')} WHERE id = ?`).run(...values);
    res.json({ message: '更新成功' });
  } catch (error) {
    console.error('更新班级设置失败:', error);
    res.status(500).json({ error: '更新班级设置失败' });
  }
});

// 教师创建班级（自动成为班主任）
router.post('/create', authenticateToken, (req, res) => {
  try {
    const { name, grade } = req.body;
    const teacherId = req.user.userId;
    const userRole = req.user.role;

    // 验证权限：只有教师可以创建班级
    if (userRole !== 'teacher' && userRole !== 'admin') {
      return res.status(403).json({ error: '只有教师可以创建班级' });
    }

    if (!name) {
      return res.status(400).json({ error: '班级名称不能为空' });
    }

    // 创建班级，教师自动成为班主任
    // 允许同时担任多个班级的班主任，故不再限制「一师一班主任」
    const slug = generateClassSlug(name, (candidate) => !!db.prepare('SELECT 1 FROM classes WHERE slug = ?').get(candidate));
    const result = db.prepare(`
      INSERT INTO classes (name, grade, slug, head_teacher_id, student_count, total_exp, created_at)
      VALUES (?, ?, ?, ?, 0, 0, datetime('now'))
    `).run(name, grade || null, slug, teacherId);

    const classId = result.lastInsertRowid;

    // 将教师添加到 class_teachers 表（新班的唯一班主任，同时也是主班主任）
    db.prepare(`
      INSERT INTO class_teachers (class_id, teacher_id, role)
      VALUES (?, ?, 'head_teacher')
    `).run(classId, teacherId);

    // 自动生成一个推荐码
    const inviteCode = generateInviteCode();
    db.prepare(`
      INSERT INTO class_invitations (class_id, invitation_code, created_by, role_filter, is_active)
      VALUES (?, ?, ?, 'any', 1)
    `).run(classId, inviteCode, teacherId);

    res.json({ 
      message: '班级创建成功', 
      class_id: classId,
      invitation_code: inviteCode,
      invitation_link: `${process.env.FRONTEND_URL || 'http://localhost:5173'}/register?invite=${inviteCode}`
    });
  } catch (error) {
    console.error('创建班级失败:', error);
    res.status(500).json({ error: '创建班级失败' });
  }
});

// 生成邀请码
router.post('/:classId/invitations', authenticateToken, (req, res) => {
  try {
    const { classId } = req.params;
    const { role_filter, max_uses, expires_at } = req.body;
    const userId = req.user.userId;
    const userRole = req.user.role;

    // 验证班级是否存在
    const cls = db.prepare('SELECT * FROM classes WHERE id = ?').get(classId);
    if (!cls) {
      return res.status(404).json({ error: '班级不存在' });
    }

    // 验证权限：只有班主任或管理员可以生成邀请码
    if (userRole !== 'admin') {
      const isHeadTeacher = db.prepare(
        `SELECT 1 FROM class_teachers WHERE class_id = ? AND teacher_id = ? AND role = 'head_teacher'`
      ).get(classId, userId);

      if (!isHeadTeacher) {
        return res.status(403).json({ error: '只有班主任可以生成邀请码' });
      }
    }

    // 生成邀请码
    const inviteCode = generateInviteCode();
    
    const result = db.prepare(`
      INSERT INTO class_invitations (class_id, invitation_code, created_by, role_filter, max_uses, expires_at, is_active)
      VALUES (?, ?, ?, ?, ?, ?, 1)
    `).run(classId, inviteCode, userId, role_filter || 'any', max_uses || null, expires_at || null);

    res.json({ 
      message: '邀请码生成成功',
      invitation_code: inviteCode,
      invitation_id: result.lastInsertRowid
    });
  } catch (error) {
    console.error('生成邀请码失败:', error);
    res.status(500).json({ error: '生成邀请码失败' });
  }
});

// 获取班级的邀请码列表
router.get('/:classId/invitations', authenticateToken, (req, res) => {
  try {
    const { classId } = req.params;
    const userId = req.user.userId;
    const userRole = req.user.role;

    // 验证班级是否存在
    const cls = db.prepare('SELECT * FROM classes WHERE id = ?').get(classId);
    if (!cls) {
      return res.status(404).json({ error: '班级不存在' });
    }

    // 验证权限：只有班主任、班级教师或管理员可以查看
    if (userRole !== 'admin') {
      const isTeacher = db.prepare(
        'SELECT id FROM class_teachers WHERE class_id = ? AND teacher_id = ?'
      ).get(classId, userId);

      if (!isTeacher) {
        return res.status(403).json({ error: '无权查看该班级的邀请码' });
      }
    }

    const invitations = db.prepare(`
      SELECT * FROM class_invitations 
      WHERE class_id = ? 
      ORDER BY created_at DESC
    `).all(classId);

    res.json({ invitations });
  } catch (error) {
    console.error('获取邀请码列表失败:', error);
    res.status(500).json({ error: '获取邀请码列表失败' });
  }
});

// 禁用/启用邀请码
router.put('/invitations/:invitationId/toggle', authenticateToken, (req, res) => {
  try {
    const { invitationId } = req.params;
    const userId = req.user.userId;
    const userRole = req.user.role;

    const invitation = db.prepare(
      'SELECT * FROM class_invitations WHERE id = ?'
    ).get(invitationId);

    if (!invitation) {
      return res.status(404).json({ error: '邀请码不存在' });
    }

    // 验证权限
    if (userRole !== 'admin') {
      const isHeadTeacher = db.prepare(
        `SELECT 1 FROM class_teachers WHERE class_id = ? AND teacher_id = ? AND role = 'head_teacher'`
      ).get(invitation.class_id, userId);

      if (!isHeadTeacher) {
        return res.status(403).json({ error: '只有班主任可以管理邀请码' });
      }
    }

    const newStatus = invitation.is_active ? 0 : 1;
    db.prepare(
      'UPDATE class_invitations SET is_active = ? WHERE id = ?'
    ).run(newStatus, invitationId);

    res.json({ 
      message: newStatus ? '邀请码已启用' : '邀请码已禁用',
      is_active: newStatus
    });
  } catch (error) {
    console.error('更新邀请码状态失败:', error);
    res.status(500).json({ error: '更新邀请码状态失败' });
  }
});

// 验证邀请码
router.post('/invitations/validate', (req, res) => {
  try {
    const { invitation_code } = req.body;

    if (!invitation_code) {
      return res.status(400).json({ error: '请提供邀请码' });
    }

    const invitation = db.prepare(`
      SELECT ci.*, c.name as class_name, c.grade, COALESCE(u.real_name, u.username) as creator_name
      FROM class_invitations ci
      JOIN classes c ON ci.class_id = c.id
      JOIN users u ON ci.created_by = u.id
      WHERE ci.invitation_code = ?
    `).get(invitation_code);

    if (!invitation) {
      return res.status(404).json({ error: '邀请码不存在' });
    }

    // 检查是否启用
    if (!invitation.is_active) {
      return res.status(400).json({ error: '该邀请码已禁用' });
    }

    // 检查是否过期
    if (invitation.expires_at && new Date(invitation.expires_at) < new Date()) {
      return res.status(400).json({ error: '该邀请码已过期' });
    }

    // 检查使用次数
    if (invitation.max_uses !== null && invitation.used_count >= invitation.max_uses) {
      return res.status(400).json({ error: '该邀请码已达到使用次数上限' });
    }

    res.json({
      valid: true,
      class_id: invitation.class_id,
      class_name: invitation.class_name,
      grade: invitation.grade,
      role_filter: invitation.role_filter,
      creator_name: invitation.creator_name
    });
  } catch (error) {
    console.error('验证邀请码失败:', error);
    res.status(500).json({ error: '验证邀请码失败' });
  }
});

// 通过邀请码注册（新用户）
router.post('/register-with-invite', async (req, res) => {
  try {
    // 邀请码注册同样是「自助注册」，必须跟着「开放注册」开关走，
    // 否则关掉注册后仍可凭邀请码建号
    if (!isFeatureEnabled('registration_enabled')) {
      return res.status(403).json({ error: '本站当前未开放注册，请联系班主任或管理员开通账号' });
    }
    const { username, password, email, real_name, role, invitation_code } = req.body;

    // 用户名统一去掉首尾空格
    const uname = String(username || '').trim();

    // 验证必填字段
    if (!uname || !password || !invitation_code) {
      return res.status(400).json({ error: '用户名、密码和邀请码为必填项' });
    }

    // 检查用户名是否已存在（忽略大小写）
    const existingUser = db.prepare('SELECT id FROM users WHERE username = ? COLLATE NOCASE').get(uname);
    if (existingUser) {
      return res.status(400).json({ error: '用户名已存在' });
    }

    // 验证邀请码
    const invitation = db.prepare(`
      SELECT * FROM class_invitations 
      WHERE invitation_code = ? AND is_active = 1
    `).get(invitation_code);

    if (!invitation) {
      return res.status(400).json({ error: '邀请码无效' });
    }

    // 检查是否过期
    if (invitation.expires_at && new Date(invitation.expires_at) < new Date()) {
      return res.status(400).json({ error: '邀请码已过期' });
    }

    // 检查使用次数
    if (invitation.max_uses !== null && invitation.used_count >= invitation.max_uses) {
      return res.status(400).json({ error: '邀请码已达到使用次数上限' });
    }

    // 检查角色限制
    if (invitation.role_filter !== 'any' && role !== invitation.role_filter) {
      return res.status(400).json({ 
        error: `该邀请码仅适用于${invitation.role_filter === 'student' ? '学生' : '教师'}` 
      });
    }

    // 角色归一化：role 可能未传（默认学生）。原实现入库存的是 'student'，
    // 但后面判断是否累加班级人数时用的是原始 role，导致学生数永远不增加。
    const finalRole = role === 'teacher' ? 'teacher' : 'student';

    // 校验班级仍然存在（原先未校验，班级被删除后邀请码仍能注册出孤儿账号）
    const targetClass = db.prepare('SELECT id FROM classes WHERE id = ?').get(invitation.class_id);
    if (!targetClass) {
      return res.status(400).json({ error: '该邀请码对应的班级已不存在' });
    }

    // 密码加密
    const passwordHash = await bcrypt.hash(password, 10);

    // 插入新用户
    const result = db.prepare(`
      INSERT INTO users (username, password_hash, email, real_name, role, class_id, status)
      VALUES (?, ?, ?, ?, ?, ?, 'active')
    `).run(uname, passwordHash, email, String(real_name || '').trim() || null, finalRole, invitation.class_id);

    const userId = result.lastInsertRowid;

    // 如果是学生，更新班级学生数
    if (finalRole === 'student') {
      db.prepare(
        'UPDATE classes SET student_count = student_count + 1 WHERE id = ?'
      ).run(invitation.class_id);
    }

    // 如果是教师，添加到 class_teachers 表
    if (finalRole === 'teacher') {
      db.prepare(`
        INSERT INTO class_teachers (class_id, teacher_id, role)
        VALUES (?, ?, 'teacher')
      `).run(invitation.class_id, userId);
    }

    // 更新邀请码使用次数
    db.prepare(
      'UPDATE class_invitations SET used_count = used_count + 1 WHERE id = ?'
    ).run(invitation.id);

    // 知会：该班班主任；无班主任时由管理员兜底
    notifyClassMemberJoined({
      classId: invitation.class_id,
      memberId: userId,
      memberName: real_name || username,
      role: finalRole,
    });

    // 生成 JWT token
    const jwtSecret = process.env.JWT_SECRET || 'your-secret-key';
    const token = jwt.sign(
      { userId, username, role: finalRole },
      jwtSecret,
      { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
    );

    res.status(201).json({
      message: '注册成功并已加入班级',
      token,
      user: {
        id: userId,
        username,
        email,
        role: finalRole,
        class_id: invitation.class_id
      }
    });
  } catch (error) {
    console.error('邀请注册失败:', error);
    res.status(500).json({ error: '注册失败' });
  }
});

// 已注册用户通过邀请码加入班级
router.post('/join-with-invite', authenticateToken, (req, res) => {
  try {
    // 已有账号凭邀请码入班同样受「开放注册」约束：
    // 公开演示期间应禁止校外人员凭邀请码蹭进班级
    if (!isFeatureEnabled('registration_enabled')) {
      return res.status(403).json({ error: '本站当前未开放注册入班，请联系班主任或管理员' });
    }
    const { invitation_code } = req.body;
    const userId = req.user.userId;
    const userRole = req.user.role;

    if (!invitation_code) {
      return res.status(400).json({ error: '请提供邀请码' });
    }

    // 验证邀请码
    const invitation = db.prepare(`
      SELECT * FROM class_invitations 
      WHERE invitation_code = ? AND is_active = 1
    `).get(invitation_code);

    if (!invitation) {
      return res.status(400).json({ error: '邀请码无效' });
    }

    // 检查是否过期
    if (invitation.expires_at && new Date(invitation.expires_at) < new Date()) {
      return res.status(400).json({ error: '邀请码已过期' });
    }

    // 检查使用次数
    if (invitation.max_uses !== null && invitation.used_count >= invitation.max_uses) {
      return res.status(400).json({ error: '邀请码已达到使用次数上限' });
    }

    // 检查角色限制
    if (invitation.role_filter !== 'any' && userRole !== invitation.role_filter) {
      return res.status(400).json({ 
        error: `该邀请码仅适用于${invitation.role_filter === 'student' ? '学生' : '教师'}` 
      });
    }

    // 检查用户是否已经在班级中（教师按 class_teachers 判断，学生按 users.class_id 判断）
    const user = db.prepare('SELECT class_id FROM users WHERE id = ?').get(userId);
    const oldClassId = user?.class_id || null;
    const newClassId = invitation.class_id;

    if (userRole === 'teacher') {
      const existingTeacher = db.prepare(
        'SELECT id FROM class_teachers WHERE class_id = ? AND teacher_id = ?'
      ).get(newClassId, userId);
      if (existingTeacher) {
        return res.status(400).json({ error: '您已经在该班级中' });
      }
      // 教师的多班级归属由 class_teachers 维护，不再覆盖 users.class_id
      // （原先直接 UPDATE users.class_id，会让教师丢失其它班级的归属）
      db.prepare(`
        INSERT INTO class_teachers (class_id, teacher_id, role)
        VALUES (?, ?, 'teacher')
      `).run(newClassId, userId);
    } else {
      if (oldClassId === newClassId) {
        return res.status(400).json({ error: '您已经在该班级中' });
      }
      // 转班时旧班减一、新班加一（原先仅在「原本没有班级」时加，转班导致学生数计数漂移）
      db.transaction(() => {
        db.prepare('UPDATE users SET class_id = ? WHERE id = ?').run(newClassId, userId);
        if (oldClassId && oldClassId !== newClassId) {
          db.prepare('UPDATE classes SET student_count = MAX(0, student_count - 1) WHERE id = ?').run(oldClassId);
        }
        db.prepare('UPDATE classes SET student_count = student_count + 1 WHERE id = ?').run(newClassId);
      })();
    }

    // 更新邀请码使用次数
    db.prepare(
      'UPDATE class_invitations SET used_count = used_count + 1 WHERE id = ?'
    ).run(invitation.id);

    // 知会：该班班主任；无班主任时由管理员兜底
    const memberRow = db.prepare('SELECT username, real_name FROM users WHERE id = ?').get(userId);
    notifyClassMemberJoined({
      classId: invitation.class_id,
      memberId: userId,
      memberName: memberRow?.real_name || memberRow?.username || '未知用户',
      role: userRole,
    });

    res.json({
      message: '成功加入班级',
      class_id: invitation.class_id
    });
  } catch (error) {
    console.error('加入班级失败:', error);
    res.status(500).json({ error: '加入班级失败' });
  }
});

// 获取教师作为班主任的班级（一位教师可同时担任多个班级的班主任）
router.get('/my-class', authenticateToken, (req, res) => {
  try {
    const userId = req.user.userId;
    const userRole = req.user.role;

    if (userRole !== 'teacher' && userRole !== 'admin') {
      return res.status(403).json({ error: '只有教师可以访问' });
    }

    const classes = getHeadTeacherClasses(userId);
    if (classes.length === 0) {
      return res.json({ class: null, classes: [] });
    }

    const withHeadNames = classes.map((c) => ({
      ...c,
      head_teachers: getHeadTeachers(c.id),
    }));

    // class 保留主班主任班级，兼容只认单班的老调用方
    res.json({ class: withHeadNames[0], classes: withHeadNames });
  } catch (error) {
    console.error('获取班级信息失败:', error);
    res.status(500).json({ error: '获取班级信息失败' });
  }
});

module.exports = router;
